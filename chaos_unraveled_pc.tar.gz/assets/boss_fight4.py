import random, math
import time as _hw_time  # machine stub
from retroPy import *
import weapons
import game_state

# =========================================================
# BUZZER — raw PWM on pins 0/1
# =========================================================
buzzer = None
buzz_end = 0
buzzing  = False

def start_buzz(freq, duration_ms):
    pass  # hardware buzzer not available on PC
def update_buzz():
    pass  # hardware buzzer not available on PC

# =========================================================
# SCREEN / WEAPON CONSTANTS  (missing from original module level)
# =========================================================
SCREEN_W    = 320
SCREEN_H    = 240
WEAPON_TYPE = "GUN"   # overridden by init() from game_state

gun_p      = weapons.Gun()
sword_p    = weapons.Sword()
trident_p  = weapons.Trident()
pickaxe_p  = weapons.Pickaxe()
pimpillo   = weapons.Pimpillo()

# Sprite handles — set by _make_sprites() inside init()
boss_obj   = None
player_obj = None
wep_sprite = None

def _make_sprites():
    global boss_obj, player_obj, wep_sprite
    boss_obj   = gameObj("boss4.rs8", 150, 40)
    player_obj = gameObj("sideclanker.rs8", 20, 180)
    player_obj.flip(1)
    wep_sprite = gameObj(
        "gun.rs8"      if WEAPON_TYPE == "GUN"      else
        "sword.rs8"    if WEAPON_TYPE == "SWORD"    else
        "trident.rs8"  if WEAPON_TYPE == "TRIDENT"  else
        "pickaxe.rs8"  if WEAPON_TYPE == "PICKAXE"  else
        "pimpillo.rs8",
        -100, -100
    )

# =========================================================
# HEALTH / PHASE
# =========================================================
BOSS_MAX_HP   = 50
PLAYER_MAX_HP = 5
boss_hp       = 50
player_hp     = 5
INV_TIME      = 40
inv_timer     = 0
phase2        = False

# =========================================================
# PLAYER STATE
# =========================================================
player_x   = 20.0
player_y   = 180.0
player_dir = 1
PLAYER_SPD = 90

# =========================================================
# MINION SYSTEM
# =========================================================
MAX_MINIONS    = 6
MINION_SPD     = 45
MINION_HIT_CD  = 30   # frames between minion punches
MINION_HP      = 3
SUMMON_CD      = 180  # frames between summons (phase1)
SUMMON_CD_P2   = 90
summon_timer   = 0

class Minion:
    def __init__(self, x, y):
        self.obj    = gameObj("minions.rs8", x, y)
        self.hp     = MINION_HP
        self.alive  = True
        self.hit_cd = 0   # cooldown before it can punch again

    def update(self, px, py):
        if not self.alive:
            return
        if self.hit_cd > 0:
            self.hit_cd -= 1
        # walk toward player
        mx = self.obj.pos_x
        my = self.obj.pos_y
        dx = px - mx;  dy = py - my
        d  = max(1, math.sqrt(dx*dx + dy*dy))
        self.obj.speed_x = (dx/d) * MINION_SPD
        self.obj.speed_y = (dy/d) * MINION_SPD
        self.obj.clamp_x(0, SCREEN_W - 16)
        self.obj.clamp_y(0, SCREEN_H - 16)
        self.obj.update()

    def try_punch(self, player_obj):
        """Returns True and resets cooldown if punch lands."""
        if self.alive and self.hit_cd == 0:
            if self.obj.collider(player_obj):
                self.hit_cd = MINION_HIT_CD
                return True
        return False

    def try_hit(self, dmg):
        if self.alive:
            self.hp -= dmg
            if self.hp <= 0:
                self.alive     = False
                self.obj.pos_x = -300
                self.obj.pos_y = -300

    def draw(self):
        if self.alive:
            self.obj.draw()
            # small HP pip above minion
            ox = int(self.obj.pos_x)
            oy = int(self.obj.pos_y)
            draw.filled_rect(ox, oy - 5, MINION_HP * 4, 2, 5)
            draw.filled_rect(ox, oy - 5, self.hp * 4,   2, 2)

minions = []

def spawn_minion():
    # find a dead slot or append if under max
    for m in minions:
        if not m.alive:
            bx = int(boss_obj.pos_x)
            by = int(boss_obj.pos_y)
            m.obj.pos_x = bx + random.randint(-20, 20)
            m.obj.pos_y = by + random.randint(10, 30)
            m.hp    = MINION_HP
            m.alive = True
            m.hit_cd = 0
            return
    if len(minions) < MAX_MINIONS:
        bx = int(boss_obj.pos_x)
        by = int(boss_obj.pos_y)
        minions.append(Minion(
            bx + random.randint(-20, 20),
            by + random.randint(10, 30)
        ))

# =========================================================
# BOSS WEAPON ATTACKS — buffed versions, all manual
# =========================================================

# --- BUFFED GUN: triple burst, faster bullets, wider spread ---
boss_bullets  = []
BOSS_GUN_CD   = 80    # frames between volleys
BOSS_GUN_SPD  = 7.0
boss_gun_timer = 0

class BossBullet:
    def __init__(self, x, y, vx, vy):
        self.x     = float(x)
        self.y     = float(y)
        self.vx    = vx
        self.vy    = vy
        self.alive = True

    def update(self):
        self.x += self.vx
        self.y += self.vy
        if self.x < -10 or self.x > SCREEN_W+10 or self.y < -10 or self.y > SCREEN_H+10:
            self.alive = False

    def draw(self):
        draw.filled_rect(int(self.x)-2, int(self.y)-2, 5, 5, 2)
        draw.filled_rect(int(self.x)-1, int(self.y)-1, 3, 3, 9)

def fire_boss_gun(bx, by, px, py):
    angle = math.atan2(py - by, px - bx)
    spreads = [-0.3, -0.15, 0, 0.15, 0.3] if phase2 else [-0.25, 0, 0.25]
    for s in spreads:
        a  = angle + s
        boss_bullets.append(BossBullet(bx, by,
                                        math.cos(a) * BOSS_GUN_SPD,
                                        math.sin(a) * BOSS_GUN_SPD))

# --- BUFFED SWORD: wide shockwave arc (drawn as expanding ring segment) ---
boss_sword_active = False
boss_sword_timer  = 0
BOSS_SWORD_CD     = 140
boss_sword_cd     = 0
BOSS_SWORD_RADIUS = 60   # bigger than player sword

def fire_boss_sword():
    global boss_sword_active, boss_sword_timer
    boss_sword_active = True
    boss_sword_timer  = 25

def draw_boss_sword(bx, by):
    if not boss_sword_active:
        return
    t   = 1 - (boss_sword_timer / 25)
    r   = int(BOSS_SWORD_RADIUS * t)
    col = 11 if boss_sword_timer % 3 < 2 else 9
    for a in range(0, 360, 10):
        rad = math.radians(a)
        px2 = bx + int(math.cos(rad) * r)
        py2 = by + int(math.sin(rad) * r)
        draw.filled_rect(px2-1, py2-1, 3, 3, col)

# --- BUFFED TRIDENT: 3 parallel lances ---
boss_lances      = []
BOSS_TRIDENT_CD  = 110
boss_trident_cd  = 0
LANCE_SPD        = 6.0
LANCE_POISON_TICKS = 5   # more than player's 3

class Lance:
    def __init__(self, x, y, vx, vy):
        self.x     = float(x)
        self.y     = float(y)
        self.vx    = vx
        self.vy    = vy
        self.alive = True
        self.len   = 0

    def update(self):
        self.x   += self.vx
        self.y   += self.vy
        self.len  = min(30, self.len + 4)
        if self.x < -20 or self.x > SCREEN_W+20 or self.y < -20 or self.y > SCREEN_H+20:
            self.alive = False

    def draw(self):
        angle = math.atan2(self.vy, self.vx)
        ex    = int(self.x + math.cos(angle) * self.len)
        ey    = int(self.y + math.sin(angle) * self.len)
        draw.line(int(self.x), int(self.y), ex, ey, 10)
        draw.line(int(self.x), int(self.y)-1, ex, ey-1, 9)

def fire_boss_trident(bx, by, px, py):
    angle = math.atan2(py - by, px - bx)
    offsets = [-8, 0, 8] if not phase2 else [-12, -4, 4, 12]
    for off in offsets:
        perp_x = -math.sin(angle) * off
        perp_y =  math.cos(angle) * off
        boss_lances.append(Lance(
            bx + perp_x, by + perp_y,
            math.cos(angle) * LANCE_SPD,
            math.sin(angle) * LANCE_SPD
        ))

# --- BUFFED PICKAXE: ground slam — shockwave circle ---
boss_slam_active = False
boss_slam_timer  = 0
boss_slam_x      = 0
boss_slam_y      = 0
BOSS_PICKAXE_CD  = 160
boss_pickaxe_cd  = 0
BOSS_SLAM_RADIUS = 70

def fire_boss_slam(bx, by):
    global boss_slam_active, boss_slam_timer, boss_slam_x, boss_slam_y
    boss_slam_active = True
    boss_slam_timer  = 30
    boss_slam_x      = bx
    boss_slam_y      = by

def draw_boss_slam():
    if not boss_slam_active:
        return
    t   = 1 - (boss_slam_timer / 30)
    r   = int(BOSS_SLAM_RADIUS * t)
    col = 6 if boss_slam_timer % 4 < 2 else 7
    draw.circle(boss_slam_x, boss_slam_y, r, col)
    if r > 4:
        draw.circle(boss_slam_x, boss_slam_y, r - 4, col)

# =========================================================
# BOSS WANDER
# =========================================================
BOSS_SPD      = 30
boss_target_x = 150.0
boss_target_y = 50.0
wander_timer  = 0
WANDER_CD     = 90

# =========================================================
# DAMAGE
# =========================================================
def try_hit_player(dmg):
    global player_hp, inv_timer
    if inv_timer == 0:
        player_hp = max(0, player_hp - dmg)
        inv_timer = INV_TIME
        start_buzz(120, 200)   # lower longer buzz on player hit

def try_hit_boss(dmg):
    global boss_hp, boss_hit_cd
    if boss_hit_cd == 0:
        boss_hp     = max(0, boss_hp - dmg)
        boss_hit_cd = BOSS_HIT_CD
        start_buzz(200, 60)   # short high blip on boss hit

# =========================================================
# INIT
# =========================================================
def init():
    global boss_hp, player_hp, inv_timer, phase2
    global boss_hit_cd, poison_ticks, poison_timer
    global boss_gun_timer, boss_sword_cd, boss_trident_cd, boss_pickaxe_cd
    global boss_sword_active, boss_sword_timer
    global boss_slam_active, boss_slam_timer
    global wander_timer, summon_timer
    global player_x, player_y, player_dir
    global WEAPON_TYPE

    WEAPON_TYPE = game_state.WEAPON_TYPE

    boss_hp    = BOSS_MAX_HP
    player_hp  = PLAYER_MAX_HP
    inv_timer  = 0
    phase2     = False

    boss_hit_cd  = 0
    poison_ticks = 0
    poison_timer = 0

    boss_gun_timer    = 40
    boss_sword_cd     = 0
    boss_trident_cd   = 0
    boss_pickaxe_cd   = 0
    boss_sword_active = False
    boss_sword_timer  = 0
    boss_slam_active  = False
    boss_slam_timer   = 0

    wander_timer = 0
    summon_timer = 60   # first summon comes quickly

    player_x   = 20.0
    player_y   = 180.0
    player_dir = 1

    boss_bullets.clear()
    boss_lances.clear()
    minions.clear()

    gun_p.bullets.clear()
    gun_p.ammo         = gun_p.max_ammo
    gun_p.reload_timer = 0
    sword_p.timer      = 0
    trident_p.timer    = 0;  trident_p.vfx = 0
    pickaxe_p.timer    = 0
    pimpillo.active      = False
    pimpillo.zone_active = False
    pimpillo.cooldown    = 0

    _make_sprites()

# =========================================================
# UPDATE — returns "WIN", "LOSE", or None
# =========================================================
def update():
    global boss_hp, player_hp, inv_timer, phase2
    global boss_hit_cd, poison_ticks, poison_timer
    global boss_gun_timer, boss_sword_cd, boss_trident_cd, boss_pickaxe_cd
    global boss_sword_active, boss_sword_timer
    global boss_slam_active, boss_slam_timer
    global wander_timer, summon_timer
    global player_x, player_y, player_dir
    global boss_target_x, boss_target_y
    global WEAPON_TYPE, wep_sprite

    # sync weapon from game_state every frame unconditionally
    if game_state.WEAPON_TYPE != WEAPON_TYPE:
        WEAPON_TYPE = game_state.WEAPON_TYPE
        wep_sprite = gameObj(
            "gun.rs8"      if WEAPON_TYPE == "GUN"      else
            "sword.rs8"    if WEAPON_TYPE == "SWORD"    else
            "trident.rs8"  if WEAPON_TYPE == "TRIDENT"  else
            "pickaxe.rs8"  if WEAPON_TYPE == "PICKAXE"  else
            "pimpillo.rs8",
            -100, -100
        )

    if inv_timer   > 0: inv_timer   -= 1
    if boss_hit_cd > 0: boss_hit_cd -= 1
    update_buzz()

    # poison ticks
    if poison_ticks > 0:
        poison_timer -= 1
        if poison_timer <= 0:
            boss_hp      = max(0, boss_hp - 1)
            poison_ticks -= 1
            poison_timer  = POISON_TICK_INTERVAL if poison_ticks > 0 else 0

    if boss_hp <= 25 and not phase2:
        phase2 = True
        start_buzz(80, 600)   # low ominous tone on phase shift

    # ---- player movement ----
    spd = PLAYER_SPD * dt()
    dx = 0.0;  dy = 0.0
    if kb.read_left()  == 0:
        dx = -spd
        if player_dir != -1:  player_dir = -1;  player_obj.flip(0)
    if kb.read_right() == 0:
        dx = spd
        if player_dir != 1:   player_dir = 1;   player_obj.flip(1)
    if kb.read_up()   == 0:   dy = -spd
    if kb.read_down() == 0:   dy =  spd
    if dx != 0 and dy != 0:   dx *= 0.707;  dy *= 0.707

    player_x = max(0, min(player_x + dx, SCREEN_W - 12))
    player_y = max(0, min(player_y + dy, SCREEN_H - 12))
    player_obj.pos_x = int(player_x)
    player_obj.pos_y = int(player_y)

    px = int(player_x);  py = int(player_y)

    # ---- player weapon input ----
    wt = game_state.WEAPON_TYPE   # always read live, never stale

    if kb.B_down():
        if   wt == "GUN":      gun_p.shoot(px, py, player_dir)
        elif wt == "SWORD":    sword_p.attack()
        elif wt == "TRIDENT":  trident_p.attack()
        elif wt == "PICKAXE":  pickaxe_p.attack()
        elif wt == "PIMPILLO": pimpillo.attack(px, py, player_dir)

    gun_p.update();  sword_p.update();  trident_p.update();  pickaxe_p.update();  pimpillo.update()

    # ---- player weapon damage to boss ----
    wx = px + 5
    for b in gun_p.bullets:
        if boss_obj.colliderPt(int(b.x), int(b.y)):
            try_hit_boss(weapons.Gun.DAMAGE);  b.alive = False

    if wt == "SWORD" and sword_p.is_busy():
        for hx, hy in sword_p.hit_points(wx, py, player_dir):
            if boss_obj.colliderPt(hx, hy):
                try_hit_boss(weapons.Sword.DAMAGE);  break

    if wt == "PICKAXE" and pickaxe_p.timer > 0:
        for hx, hy in pickaxe_p.hit_points(wx, py, player_dir):
            if boss_obj.colliderPt(hx, hy):
                try_hit_boss(weapons.Pickaxe.DAMAGE);  break

    if wt == "TRIDENT" and trident_p.timer > 0:
        for hx, hy in trident_p.hit_points(wx, py, player_dir):
            if boss_obj.colliderPt(hx, hy):
                try_hit_boss(weapons.Trident.DAMAGE)
                poison_ticks = weapons.Trident.POISON_TICKS
                poison_timer = POISON_TICK_INTERVAL
                break

    if wt == "PIMPILLO":
        pimpillo.hit_enemy(lambda hx, hy: boss_obj.colliderPt(hx, hy))
        for hx, hy in pimpillo.zone_hit_points():
            if boss_obj.colliderPt(hx, hy):
                try_hit_boss(weapons.Pimpillo.DAMAGE);  break

    # ---- player weapon damage to minions ----
    for m in minions:
        if not m.alive:
            continue
        for b in gun_p.bullets:
            if m.obj.colliderPt(int(b.x), int(b.y)):
                m.try_hit(weapons.Gun.DAMAGE);  b.alive = False;  break
        if wt == "SWORD" and sword_p.is_busy():
            for hx, hy in sword_p.hit_points(wx, py, player_dir):
                if m.obj.colliderPt(hx, hy):
                    m.try_hit(weapons.Sword.DAMAGE);  break
        if wt == "PICKAXE" and pickaxe_p.timer > 0:
            for hx, hy in pickaxe_p.hit_points(wx, py, player_dir):
                if m.obj.colliderPt(hx, hy):
                    m.try_hit(weapons.Pickaxe.DAMAGE);  break
        if wt == "TRIDENT" and trident_p.timer > 0:
            for hx, hy in trident_p.hit_points(wx, py, player_dir):
                if m.obj.colliderPt(hx, hy):
                    m.try_hit(weapons.Trident.DAMAGE);  break
        if wt == "PIMPILLO":
            pimpillo.hit_enemy(lambda hx, hy: m.obj.colliderPt(hx, hy))
            for hx, hy in pimpillo.zone_hit_points():
                if m.obj.colliderPt(hx, hy):
                    m.try_hit(weapons.Pimpillo.DAMAGE);  break

    # ---- boss wander ----
    bx = int(boss_obj.pos_x);  by = int(boss_obj.pos_y)
    wander_timer += 1
    if wander_timer >= WANDER_CD:
        wander_timer  = 0
        boss_target_x = float(random.randint(40, SCREEN_W - 40))
        boss_target_y = float(random.randint(10, SCREEN_H // 3))

    wdx = boss_target_x - bx;  wdy = boss_target_y - by
    wd  = max(1, math.sqrt(wdx*wdx + wdy*wdy))
    if wd > 3:
        boss_obj.speed_x = (wdx/wd) * BOSS_SPD
        boss_obj.speed_y = (wdy/wd) * BOSS_SPD
    else:
        boss_obj.speed_x = 0;  boss_obj.speed_y = 0
    boss_obj.clamp_x(10, SCREEN_W - 30)
    boss_obj.clamp_y(5,  SCREEN_H // 3)
    boss_obj.update()

    bx = int(boss_obj.pos_x);  by = int(boss_obj.pos_y)

    # =========================================================
    # BOSS WEAPON ATTACKS — all fire independently
    # =========================================================
    atk_mul = 2 if phase2 else 1   # phase2 halves all cooldowns

    # BUFFED GUN
    boss_gun_timer += 1
    if boss_gun_timer >= BOSS_GUN_CD // atk_mul:
        boss_gun_timer = 0
        fire_boss_gun(bx, by, px, py)

    # BUFFED SWORD shockwave
    boss_sword_cd += 1
    if boss_sword_cd >= BOSS_SWORD_CD // atk_mul:
        boss_sword_cd = 0
        fire_boss_sword()

    if boss_sword_active:
        boss_sword_timer -= 1
        if boss_sword_timer <= 0:
            boss_sword_active = False

    # BUFFED TRIDENT lances
    boss_trident_cd += 1
    if boss_trident_cd >= BOSS_TRIDENT_CD // atk_mul:
        boss_trident_cd = 0
        fire_boss_trident(bx, by, px, py)

    # BUFFED PICKAXE slam
    boss_pickaxe_cd += 1
    if boss_pickaxe_cd >= BOSS_PICKAXE_CD // atk_mul:
        boss_pickaxe_cd = 0
        fire_boss_slam(bx, by)

    if boss_slam_active:
        boss_slam_timer -= 1
        if boss_slam_timer <= 0:
            boss_slam_active = False

    # =========================================================
    # SUMMON MINIONS
    # =========================================================
    summon_timer += 1
    cd = SUMMON_CD_P2 if phase2 else SUMMON_CD
    if summon_timer >= cd:
        summon_timer = 0
        spawn_minion()
        start_buzz(150, 150)   # mid tone on summon
        if phase2:
            spawn_minion()

    # =========================================================
    # UPDATE BOSS PROJECTILES + PLAYER DAMAGE
    # =========================================================

    # boss bullets
    i = 0
    while i < len(boss_bullets):
        b = boss_bullets[i]
        b.update()
        if not b.alive:
            boss_bullets.pop(i)
        else:
            if player_obj.colliderPt(int(b.x), int(b.y)):
                try_hit_player(1)
                boss_bullets.pop(i)
            else:
                i += 1

    # boss lances
    i = 0
    while i < len(boss_lances):
        l = boss_lances[i]
        l.update()
        if not l.alive:
            boss_lances.pop(i)
        else:
            tip_x = int(l.x + math.cos(math.atan2(l.vy, l.vx)) * l.len)
            tip_y = int(l.y + math.sin(math.atan2(l.vy, l.vx)) * l.len)
            if player_obj.colliderPt(tip_x, tip_y) or player_obj.colliderPt(int(l.x), int(l.y)):
                try_hit_player(2)   # lances hit harder
                if poison_ticks == 0:
                    poison_ticks = LANCE_POISON_TICKS
                    poison_timer = POISON_TICK_INTERVAL
                boss_lances.pop(i)
            else:
                i += 1

    # boss sword shockwave player check
    if boss_sword_active:
        t = 1 - (boss_sword_timer / 25)
        r = int(BOSS_SWORD_RADIUS * t)
        mx = int(player_obj.mid_x);  my = int(player_obj.mid_y)
        dist = math.sqrt((mx - bx)**2 + (my - by)**2)
        if abs(dist - r) < 8:
            try_hit_player(2)

    # boss slam shockwave player check
    if boss_slam_active:
        t = 1 - (boss_slam_timer / 30)
        r = int(BOSS_SLAM_RADIUS * t)
        mx = int(player_obj.mid_x);  my = int(player_obj.mid_y)
        dist = math.sqrt((mx - boss_slam_x)**2 + (my - boss_slam_y)**2)
        if abs(dist - r) < 10:
            try_hit_player(1)

    # =========================================================
    # UPDATE MINIONS + PUNCH PLAYER
    # =========================================================
    for m in minions:
        m.update(px, py)
        if m.try_punch(player_obj):
            try_hit_player(1)

    if boss_hp <= 0:
        pass  # no buzzer
        return "WIN"
    if player_hp <= 0:
        pass  # no buzzer
        return "LOSE"
    return None

# =========================================================
# DRAW
# =========================================================
def draw_scene():
    draw.clear(0)

    # boss VFX (behind boss sprite)
    draw_boss_slam()
    draw_boss_sword(int(boss_obj.pos_x), int(boss_obj.pos_y))

    for l in boss_lances:
        l.draw()
    for b in boss_bullets:
        b.draw()

    # minions
    for m in minions:
        m.draw()

    boss_obj.draw()
    # border so boss is always visible
    draw.rect(int(boss_obj.pos_x)-2, int(boss_obj.pos_y)-2,
              boss_obj.width+4, boss_obj.height+4, 2)

    player_obj.draw()

    px = int(player_x);  py = int(player_y)
    bx = int(boss_obj.pos_x);  by = int(boss_obj.pos_y)

    if wep_sprite:
        wep_sprite.pos_x = px+5;  wep_sprite.pos_y = py
        wep_sprite.draw()
    gun_p.draw(draw)
    sword_p.draw(draw, px+5, py, player_dir)
    trident_p.draw(draw, px+5, py, player_dir)
    pickaxe_p.draw(draw, px+5, py, player_dir)
    pimpillo.draw(draw)

    # boss HP bar
    draw.filled_rect(bx-40, by-16, 80, 5, 7)
    draw.filled_rect(bx-40, by-16, int(80*(boss_hp/BOSS_MAX_HP)), 5, 2)
    if phase2:
        draw.text("PHASE 2", bx-18, by-26, 2)

    # minion count
    alive_m = sum(1 for m in minions if m.alive)
    if alive_m > 0:
        draw.text("MINIONS:"+str(alive_m), bx-28, by-34, 6)

    # poison ticks on boss
    if poison_ticks > 0:
        for i in range(poison_ticks):
            draw.filled_rect(bx-40+i*10, by-44, 8, 4, 11)

    # player HP
    draw.filled_rect(4, 4, 60, 5, 7)
    draw.filled_rect(4, 4, int(60*(player_hp/PLAYER_MAX_HP)), 5, 3)

    # gun reload bar
    if game_state.WEAPON_TYPE == "GUN":
        bc = 4 if gun_p.reload_timer > 0 else 9
        draw.filled_rect(4, 12, 60, 3, 7)
        draw.filled_rect(4, 12, int(60*(gun_p.reload_progress()/gun_p.max_ammo)), 3, bc)