import random, math
from retroPy import *
import weapons
import game_state

# =========================================================
# SPRITES
# =========================================================
player     = None
bosh       = None
wep_sprite = None

def _make_sprites():
    global player, bosh, wep_sprite
    player     = gameObj("sideclanker.rs8", 20, 32)
    bosh       = gameObj("Gard.rs8", 200, 120)
    player.flip(1)
    wep_sprite = gameObj(
        "gun.rs8"     if WEAPON_TYPE == "GUN"     else
        "sword.rs8"   if WEAPON_TYPE == "SWORD"   else
        "trident.rs8" if WEAPON_TYPE == "TRIDENT" else
        "pickaxe.rs8"  if WEAPON_TYPE == "PICKAXE" else
        "pimpillo.rs8",
        -100, -100
    )

# =========================================================
# WEAPONS
# =========================================================
WEAPON_TYPE = "TRIDENT"   # fallback — overridden by game_state at runtime
gun     = weapons.Gun()
sword   = weapons.Sword()
trident = weapons.Trident()
pickaxe   = weapons.Pickaxe()
pimpillo  = weapons.Pimpillo()

# =========================================================
# HEALTH
# =========================================================
BOSS_MAX_HP   = 30
PLAYER_MAX_HP = 5
boss_hp       = 30
player_hp     = 5

INV_TIME  = 60
inv_timer = 0

boss_hit_cd       = 0
BOSS_HIT_COOLDOWN = 18

# =========================================================
# POISON
# =========================================================
poison_ticks = 0
poison_timer = 0
POISON_TICK_INTERVAL = 60

# =========================================================
# PLAYER DIR
# =========================================================
player_dir = 1

# =========================================================
# BOSS STATE MACHINE
# =========================================================
BOSH_SPEED = 40
JAB_SPEED  = 160

bosh_target_x = 200
bosh_target_y = 120

IDLE, PRE, ROCK, JAB, HAMMER, RECOVER = range(6)
state       = IDLE
btimer      = 0
next_attack = 180
attack_type = None
jab_dx      = 0.0
jab_dy      = 0.0

# =========================================================
# ROCK SYSTEM
# =========================================================
rocks = []

class Rock:
    def __init__(self):
        self.obj     = gameObj("rok.rs8", -50, -50, 100)
        self.active  = False
        self.speed_y = 0

    def spawn(self):
        self.active    = True
        self.obj.pos_x = random.randint(0, 320)
        self.obj.pos_y = -random.randint(20, 120)
        self.speed_y   = 2 + random.randint(1, 3)

    def update(self):
        if not self.active: return
        self.obj.pos_y += self.speed_y
        if self.obj.pos_y > 240: self.deactivate()

    def deactivate(self):
        self.active = False;  self.obj.pos_x = -100;  self.obj.pos_y = -100

    def draw(self):
        if self.active: self.obj.draw()

for _ in range(12):
    rocks.append(Rock())

def spawn_rock():
    for r in rocks:
        if not r.active:
            r.spawn();  return

# =========================================================
# HAMMER FX
# =========================================================
hammer_timer = 0

def draw_hammer_arc(x, y):
    for i in range(18):
        t     = i / 18
        angle = math.pi * (0.2 + 0.6 * t)
        px    = int(x + math.cos(angle) * 120)
        py    = int(y + math.sin(angle) * 120)
        shade = 6 + int(8 * (1 - t))
        draw.circle(px, py, 10, shade)

# =========================================================
# DAMAGE
# =========================================================
def hit_boss(dmg):
    global boss_hp
    boss_hp = max(0, boss_hp - dmg)

def try_hit_boss(dmg):
    global boss_hit_cd
    if boss_hit_cd == 0:
        hit_boss(dmg);  boss_hit_cd = BOSS_HIT_COOLDOWN

def try_hit_player(dmg):
    global player_hp, inv_timer
    if inv_timer == 0:
        player_hp = max(0, player_hp - dmg);  inv_timer = INV_TIME

def apply_poison():
    global poison_ticks, poison_timer
    poison_ticks = weapons.Trident.POISON_TICKS
    poison_timer = POISON_TICK_INTERVAL

# =========================================================
# INIT — called by main.py when switching to boss scene
# =========================================================
def init():
    global WEAPON_TYPE
    WEAPON_TYPE = game_state.WEAPON_TYPE
    global boss_hp, player_hp, inv_timer, boss_hit_cd
    global poison_ticks, poison_timer, state, btimer, next_attack
    global bosh_target_x, bosh_target_y, attack_type, jab_dx, jab_dy
    global hammer_timer, player_dir

    boss_hp      = BOSS_MAX_HP
    player_hp    = PLAYER_MAX_HP
    inv_timer    = 0
    boss_hit_cd  = 0
    poison_ticks = 0
    poison_timer = 0
    state        = IDLE
    btimer       = 0
    next_attack  = 180
    attack_type  = None
    jab_dx       = 0.0
    jab_dy       = 0.0
    hammer_timer = 0
    player_dir   = 1

    bosh_target_x = random.randint(50, 270)
    bosh_target_y = random.randint(50, 190)

    for r in rocks:
        r.deactivate()

    # reset weapons
    gun.bullets.clear()
    gun.ammo        = gun.max_ammo
    gun.reload_timer = 0
    sword.timer     = 0
    trident.timer   = 0
    trident.vfx     = 0
    pickaxe.timer   = 0

    _make_sprites()

# =========================================================
# UPDATE — returns "WIN", "LOSE", or None
# =========================================================
def update():
    global state, btimer, next_attack, attack_type
    global bosh_target_x, bosh_target_y, hammer_timer
    global player_hp, inv_timer, boss_hit_cd
    global jab_dx, jab_dy, player_dir, poison_ticks, poison_timer

    btimer += 1

    if boss_hit_cd > 0: boss_hit_cd -= 1
    if inv_timer   > 0: inv_timer   -= 1

    # poison ticks (bypass hit cooldown)
    if poison_ticks > 0:
        poison_timer -= 1
        if poison_timer <= 0:
            hit_boss(1);  poison_ticks -= 1
            poison_timer = POISON_TICK_INTERVAL if poison_ticks > 0 else 0

    # player movement
    speed = 70 * dt()
    if kb.read_left()  == 0:
        player.speed_x = -speed * 60
        if player_dir != -1:  player_dir = -1;  player.flip(0)
    elif kb.read_right() == 0:
        player.speed_x = speed * 60
        if player_dir != 1:   player_dir = 1;   player.flip(1)
    else:
        player.speed_x = 0

    if kb.read_up()   == 0: player.speed_y = -speed * 60
    elif kb.read_down() == 0: player.speed_y = speed * 60
    else: player.speed_y = 0

    player.clamp_x(0, 305);  player.clamp_y(0, 220)
    player.update()

    px = int(player.pos_x);  py = int(player.pos_y)
    bx = int(bosh.pos_x);    by = int(bosh.pos_y)
    dxp  = px - bx;  dyp = py - by
    dist = max(1, math.sqrt(dxp*dxp + dyp*dyp))

    # weapons
    if kb.B_down():
        if   WEAPON_TYPE == "GUN":      gun.shoot(px, py, player_dir)
        elif WEAPON_TYPE == "SWORD":    sword.attack()
        elif WEAPON_TYPE == "TRIDENT":  trident.attack()
        elif WEAPON_TYPE == "PICKAXE":  pickaxe.attack()
        elif WEAPON_TYPE == "PIMPILLO": pimpillo.attack(px, py, player_dir)

    gun.update();  sword.update();  trident.update();  pickaxe.update();  pimpillo.update()

    # rocks + player damage
    for r in rocks:
        if r.active:
            r.update()
            if r.active:
                if player.colliderPt(int(r.obj.pos_x), int(r.obj.pos_y)):
                    try_hit_player(1);  r.deactivate()

    # ---- weapon damage ----
    wx = px + 5

    for b in gun.bullets:
        if bosh.colliderPt(int(b.x), int(b.y)):
            try_hit_boss(weapons.Gun.DAMAGE);  b.alive = False

    if WEAPON_TYPE == "SWORD" and sword.is_busy():
        for hx, hy in sword.hit_points(wx, py, player_dir):
            if bosh.colliderPt(hx, hy):
                try_hit_boss(weapons.Sword.DAMAGE);  break

    if WEAPON_TYPE == "PICKAXE" and pickaxe.timer > 0:
        for hx, hy in pickaxe.hit_points(wx, py, player_dir):
            if bosh.colliderPt(hx, hy):
                try_hit_boss(weapons.Pickaxe.DAMAGE);  break

    if WEAPON_TYPE == "TRIDENT" and trident.timer > 0:
        for hx, hy in trident.hit_points(wx, py, player_dir):
            if bosh.colliderPt(hx, hy):
                try_hit_boss(weapons.Trident.DAMAGE);  apply_poison();  break

    if WEAPON_TYPE == "PIMPILLO":
        # explode on direct contact while flying
        pimpillo.hit_enemy(lambda hx, hy: bosh.colliderPt(hx, hy))
        # zone damage after landing
        for hx, hy in pimpillo.zone_hit_points():
            if bosh.colliderPt(hx, hy):
                try_hit_boss(weapons.Pimpillo.DAMAGE);  break

    # boss AI
    if state == IDLE:
        dx = bosh_target_x - bx;  dy = bosh_target_y - by
        d  = max(1, math.sqrt(dx*dx + dy*dy))
        if d < 5:
            bosh_target_x = random.randint(20, 300)
            bosh_target_y = random.randint(20, 220)
        bosh.speed_x = (dx/d) * BOSH_SPEED
        bosh.speed_y = (dy/d) * BOSH_SPEED
        if btimer > next_attack:
            roll = random.randint(1, 100)
            attack_type = "ROCK" if roll < 40 else "JAB" if roll < 80 else "HAMMER"
            state = PRE;  btimer = 0;  bosh.currNdx(1)

    elif state == PRE:
        bosh.speed_x = 0;  bosh.speed_y = 0
        if btimer == 1 and attack_type == "JAB":
            snap_d = max(1, math.sqrt(dxp*dxp + dyp*dyp))
            jab_dx = dxp/snap_d;  jab_dy = dyp/snap_d
        if btimer > 15:
            btimer = 0
            state  = ROCK if attack_type=="ROCK" else JAB if attack_type=="JAB" else HAMMER

    elif state == ROCK:
        bosh.speed_x = 0;  bosh.speed_y = 0
        if btimer == 1:
            for _ in range(random.randint(7, 10)): spawn_rock()
        if btimer > 90:
            state = RECOVER;  btimer = 0

    elif state == JAB:
        bosh.speed_x = jab_dx * JAB_SPEED
        bosh.speed_y = jab_dy * JAB_SPEED
        bosh.clamp_x(0, 305);  bosh.clamp_y(0, 220)
        if player.collider(bosh): try_hit_player(1)
        if btimer > 40:
            state = RECOVER;  btimer = 0

    elif state == HAMMER:
        bosh.speed_x = 0;  bosh.speed_y = 0
        if btimer == 1: hammer_timer = 60
        if hammer_timer > 0: hammer_timer -= 1
        if btimer == 40 and player.collider(bosh): try_hit_player(1)
        if btimer > 80:
            state = RECOVER;  btimer = 0

    elif state == RECOVER:
        dx = bosh_target_x - bx;  dy = bosh_target_y - by
        d  = max(1, math.sqrt(dx*dx + dy*dy))
        bosh.speed_x = (dx/d) * BOSH_SPEED
        bosh.speed_y = (dy/d) * BOSH_SPEED
        if btimer > 25:
            state = IDLE;  btimer = 0
            next_attack = random.randint(150, 350)
            bosh.currNdx(0)

    bosh.update()

    # general contact damage
    if player.collider(bosh):
        try_hit_player(1)

    # win / lose checks
    if boss_hp <= 0:   return "WIN"
    if player_hp <= 0: return "LOSE"
    return None

# =========================================================
# DRAW
# =========================================================
def draw_scene():
    draw.clear(0)

    px = int(player.pos_x);  py = int(player.pos_y)
    bx = int(bosh.pos_x);    by = int(bosh.pos_y)

    player.draw();  bosh.draw()
    wep_sprite.pos_x = px + 5;  wep_sprite.pos_y = py;  wep_sprite.draw()

    gun.draw(draw)
    sword.draw(draw, px+5, py, player_dir)
    trident.draw(draw, px+5, py, player_dir)
    pickaxe.draw(draw, px+5, py, player_dir)
    pimpillo.draw(draw)

    for r in rocks: r.draw()

    if state == HAMMER and hammer_timer > 0:
        draw_hammer_arc(bx, by)

    # boss HP
    draw.filled_rect(bx-40, by-35, 80, 6, 7)
    draw.filled_rect(bx-40, by-35, int(80*(boss_hp/BOSS_MAX_HP)), 6, 2)

    if poison_ticks > 0:
        for i in range(poison_ticks):
            draw.filled_rect(bx-40+i*10, by-44, 8, 4, 11)

    # player HP
    draw.filled_rect(10, 10, 60, 6, 7)
    draw.filled_rect(10, 10, int(60*(player_hp/PLAYER_MAX_HP)), 6, 3)

    if WEAPON_TYPE == "GUN":
        bar_col = 4 if gun.reload_timer > 0 else 9
        draw.filled_rect(10, 20, 60, 4, 7)
        draw.filled_rect(10, 20, int(60*(gun.reload_progress()/gun.max_ammo)), 4, bar_col)

    state_names = ["IDLE","PRE","ROCK","JAB","HAMMER","RECOVER"]
    draw.text(state_names[state], 10, 28, 15)