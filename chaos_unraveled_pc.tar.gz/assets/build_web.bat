@echo off
echo [1/3] Building...
python -m pygbag --build --width 960 --height 720 main.py
echo [2/3] Patching HTML...
python patch_html.py
echo [3/3] Serving at http://localhost:8000  (Ctrl+C to stop)
python serve.py
