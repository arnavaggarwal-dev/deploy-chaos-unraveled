import math
from retroPy import *
import game_state
import boss_fight
import boss_fight2
import boss_fight3
import boss_fight4

# =========================================================
# PANTHEON — Boss Rush
# All 4 bosses back to back, HP carries over between fights.
# No refills. Lose at any point = start over from boss 1.
#
# Order: Boss1 → Boss2 → Boss3 → Boss4 (The Witch)
# Unlock: all 4 boss keys obtained at least once
# =========================================================

BOSS_ORDER = ["BOSS1", "BOSS2", "BOSS3", "BOSS4"]
BOSS_NAMES = {
    "BOSS1": "THE GUARDIAN",
    "BOSS2": "THE SOCCER DEMON",
    "BOSS3": "THE ICE SPIRIT",
    "BOSS4": "THE WITCH",
}

# maps each boss to its module
BOSS_MODULES = {
    "BOSS1": boss_fight,
    "BOSS2": boss_fight2,
    "BOSS3": boss_fight3,
    "BOSS4": boss_fight4,
}

# =========================================================
# STATE
# =========================================================
current_index   = 0    # which boss in BOSS_ORDER we're on
phase           = "INTRO"  # INTRO | FIGHTING | TRANSITION | CLEARED | FAILED
transition_timer = 0
TRANSITION_HOLD  = 120   # frames between bosses
intro_timer      = 0
INTRO_HOLD       = 180

# player HP carried over — set once at start, passed into each boss init
carried_hp = 5

# =========================================================
# INIT — called when entering the pantheon
# =========================================================
def init():
    global current_index, phase, transition_timer, intro_timer, carried_hp

    current_index    = 0
    phase            = "INTRO"
    intro_timer      = INTRO_HOLD
    transition_timer = 0
    carried_hp       = 5   # full HP at the start of the run

def _start_current_boss():
    """Init the current boss module and inject carried HP."""
    global carried_hp
    boss_id = BOSS_ORDER[current_index]
    mod     = BOSS_MODULES[boss_id]
    mod.init()
    # override the boss's player HP with whatever we carried in
    mod.player_hp = carried_hp

# =========================================================
# UPDATE — returns "WIN", "LOSE", or None
# =========================================================
def update():
    global current_index, phase, transition_timer, intro_timer, carried_hp

    # ---- INTRO ----
    if phase == "INTRO":
        intro_timer -= 1
        if intro_timer <= 0 or kb.A_down():
            phase = "FIGHTING"
            _start_current_boss()
        return None

    # ---- TRANSITION between bosses ----
    if phase == "TRANSITION":
        transition_timer -= 1
        if transition_timer <= 0:
            current_index += 1
            if current_index >= len(BOSS_ORDER):
                phase = "CLEARED"
                game_state.pantheon_completed = True
            else:
                phase = "FIGHTING"
                _start_current_boss()
        return None

    # ---- CLEARED / FAILED — handled by main.py ----
    if phase in ("CLEARED", "FAILED"):
        return None

    # ---- FIGHTING ----
    if phase == "FIGHTING":
        boss_id = BOSS_ORDER[current_index]
        mod     = BOSS_MODULES[boss_id]
        outcome = mod.update()

        if outcome == "LOSE":
            carried_hp = 0
            phase      = "FAILED"
            return "LOSE"

        if outcome == "WIN":
            # carry HP forward
            carried_hp       = mod.player_hp
            phase            = "TRANSITION"
            transition_timer = TRANSITION_HOLD

        return None

    return None

# =========================================================
# DRAW
# =========================================================
def draw_scene():
    if phase == "INTRO":
        _draw_intro()
        return

    if phase == "TRANSITION":
        _draw_transition()
        return

    if phase == "CLEARED":
        _draw_cleared()
        return

    if phase == "FAILED":
        _draw_failed()
        return

    # FIGHTING — delegate to current boss draw
    if phase == "FIGHTING":
        boss_id = BOSS_ORDER[current_index]
        BOSS_MODULES[boss_id].draw_scene()
        _draw_hud_overlay()

def _draw_hud_overlay():
    """Boss counter + carried HP drawn over the fight."""
    # progress pips
    for i, bid in enumerate(BOSS_ORDER):
        col = 10 if i < current_index else (15 if i == current_index else 5)
        draw.filled_rect(130 + i * 16, 4, 12, 5, col)
        draw.rect(130 + i * 16, 4, 12, 5, 7)
    draw.text("PANTHEON", 130, 11, 7)

def _draw_intro():
    draw.clear(0)
    draw.filled_rect(20, 20, 280, 200, 1)
    draw.rect(20, 20, 280, 200, 15)
    draw.text("PANTHEON OF TRIALS", 68, 40, 15)
    draw.text("Face all 4 bosses.", 85, 65, 7)
    draw.text("HP carries between fights.", 58, 80, 7)
    draw.text("Fall once — start over.", 68, 95, 2)

    # boss list
    for i, bid in enumerate(BOSS_ORDER):
        draw.text(str(i+1)+". "+BOSS_NAMES[bid], 80, 120 + i * 14, 9)

    draw.text("[ A ] to begin", 108, 196, 5)
    # flicker
    if (intro_timer // 10) % 2 == 0:
        draw.text("ARE YOU READY?", 100, 210, 15)

def _draw_transition():
    draw.clear(0)
    draw.filled_rect(20, 60, 280, 120, 1)
    draw.rect(20, 60, 280, 120, 10)

    beaten = BOSS_ORDER[current_index - 1] if current_index > 0 else BOSS_ORDER[0]
    draw.text(BOSS_NAMES[beaten] + " DEFEATED", 60, 85, 10)

    if current_index < len(BOSS_ORDER):
        draw.text("NEXT:", 140, 105, 7)
        draw.text(BOSS_NAMES[BOSS_ORDER[current_index]], 100, 118, 15)

    # carried HP bar
    draw.text("HP carried:", 100, 140, 7)
    draw.filled_rect(100, 150, 120, 6, 5)
    draw.filled_rect(100, 150, int(120 * (carried_hp / 5)), 6, 3)

    # countdown dots
    pct = 1.0 - (transition_timer / TRANSITION_HOLD)
    draw.filled_rect(100, 162, int(120 * pct), 3, 7)

def _draw_cleared():
    draw.clear(0)
    draw.filled_rect(10, 10, 300, 220, 1)
    draw.rect(10, 10, 300, 220, 15)
    draw.text("PANTHEON CLEARED!", 72, 50, 10)
    draw.text("All 4 bosses vanquished.", 65, 75, 15)
    draw.text("You are the champion.", 72, 92, 9)
    draw.text("Remaining HP:", 100, 120, 7)
    draw.filled_rect(100, 132, 120, 6, 5)
    draw.filled_rect(100, 132, int(120 * (carried_hp / 5)), 6, 3)
    draw.text("[ A ] to return", 108, 180, 5)

def _draw_failed():
    draw.clear(0)
    draw.filled_rect(20, 60, 280, 120, 1)
    draw.rect(20, 60, 280, 120, 2)
    fallen_at = BOSS_NAMES[BOSS_ORDER[current_index]]
    draw.text("PANTHEON FAILED.", 90, 80, 2)
    draw.text("Fell at:", 118, 100, 7)
    draw.text(fallen_at, 100, 114, 9)
    draw.text("[ A ] to retry", 108, 150, 5)