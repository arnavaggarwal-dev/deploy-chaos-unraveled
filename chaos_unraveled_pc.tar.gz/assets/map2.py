import math
from retroPy import *
import game_state

# =========================================================
# MAP 2 — ALL OF THE FIGHTERS
# A second arena accessed through the pantheon gate.
# Features silhouettes of all 4 bosses as decorations.
# A gate in the top-right corner leads to the real Pantheon.
# =========================================================

TILE   = 16
MAP_W  = 20
MAP_H  = 15

SCREEN_W = 320
SCREEN_H = 240

COLOR_FLOOR = 5   # darker floor than map1
COLOR_WALL  = 6
COLOR_GATE  = 9   # gold for the pantheon gate

# =========================================================
# MAP DATA — 20x15 arena
# 0=floor  1=wall
# =========================================================
# fmt: off
MAP2 = bytearray([
    1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
    1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
    1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
    1,0,0,1,1,0,0,0,0,0,0,0,0,0,0,1,1,0,0,1,
    1,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,1,
    1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
    1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
    1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
    1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
    1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
    1,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,1,
    1,0,0,1,1,0,0,0,0,0,0,0,0,0,0,1,1,0,0,1,
    1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
    1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
    1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
])
# fmt: on

# =========================================================
# MAP HELPERS
# =========================================================
def _xy(col, row):  return row * MAP_W + col

def _get(col, row):
    if 0 <= col < MAP_W and 0 <= row < MAP_H:
        return MAP2[_xy(col, row)]
    return 1

def _is_wall(col, row): return _get(col, row) == 1

# =========================================================
# PANTHEON GATE — top-right corner
# =========================================================
GATE_COL = 17
GATE_ROW = 1
GATE_W   = 2
GATE_H   = 2
gate_pulse = 0   # animation counter

# =========================================================
# PLAYER STATE
# =========================================================
player_x    = float(TILE * 2)
player_y    = float(TILE * 10)
player_obj  = None
player_w    = 12
player_h    = 12
player_spd  = 90
player_dir  = 1
facing_down = False
facing_up   = False

cam_x = 0
cam_y = 0

# =========================================================
# BOSS SILHOUETTE POSITIONS (drawn manually as shapes)
# just decorative — col, row, label, color
# =========================================================
SILHOUETTES = [
    (3,  3,  "1", 7),
    (15, 3,  "2", 9),
    (3,  10, "3", 12),
    (15, 10, "4", 2),
]

# =========================================================
# INIT
# =========================================================
def init():
    global player_x, player_y, player_obj, player_w, player_h
    global player_spd, player_dir, facing_down, facing_up

    # inherit profile from game_state
    from map_level import PROFILES, profile_objs
    selected   = game_state.selected_profile
    p          = PROFILES[selected]
    player_obj = profile_objs[selected]
    player_w   = p["w"]
    player_h   = p["h"]
    player_spd = p["speed"]
    player_dir = 1
    facing_down = False
    facing_up   = False
    player_obj.flip(1)

    # spawn centre of map
    player_x = float((MAP_W // 2) * TILE)
    player_y = float((MAP_H // 2) * TILE)

# =========================================================
# MOVEMENT WITH WALL SLIDING
# =========================================================
def _move(dx, dy):
    global player_x, player_y

    new_x = player_x + dx
    cl = int(new_x) // TILE;  cr = int(new_x + player_w - 1) // TILE
    rt = int(player_y) // TILE; rb = int(player_y + player_h - 1) // TILE
    if not (_is_wall(cl,rt) or _is_wall(cl,rb) or _is_wall(cr,rt) or _is_wall(cr,rb)):
        player_x = new_x

    new_y = player_y + dy
    cl = int(player_x) // TILE;  cr = int(player_x + player_w - 1) // TILE
    rt = int(new_y) // TILE; rb = int(new_y + player_h - 1) // TILE
    if not (_is_wall(cl,rt) or _is_wall(cl,rb) or _is_wall(cr,rt) or _is_wall(cr,rb)):
        player_y = new_y

    player_x = max(0, min(player_x, MAP_W * TILE - player_w))
    player_y = max(0, min(player_y, MAP_H * TILE - player_h))

def _update_camera():
    global cam_x, cam_y
    cam_x = max(0, min(int(player_x) - SCREEN_W//2, MAP_W*TILE - SCREEN_W))
    cam_y = max(0, min(int(player_y) - SCREEN_H//2, MAP_H*TILE - SCREEN_H))

# =========================================================
# UPDATE — returns "PANTHEON" or None
# =========================================================
def update():
    global player_dir, facing_down, facing_up, player_obj, gate_pulse

    gate_pulse += 1

    spd = player_spd * dt()
    dx = 0.0;  dy = 0.0

    if kb.read_left()  == 0:
        dx = -spd
        if player_dir != -1:  player_dir = -1;  player_obj.flip(0)
    if kb.read_right() == 0:
        dx = spd
        if player_dir != 1:   player_dir = 1;   player_obj.flip(1)
    if kb.read_up()   == 0:   dy = -spd
    if kb.read_down() == 0:   dy =  spd
    if dx != 0 and dy != 0:   dx *= 0.707;  dy *= 0.707

    # sprite swap on vertical direction
    now_down = kb.read_down() == 0
    now_up   = kb.read_up()   == 0
    if now_down != facing_down or now_up != facing_up:
        facing_down = now_down;  facing_up = now_up
        from map_level import profile_objs
        if facing_down:
            player_obj = profile_objs[1]
        elif facing_up:
            player_obj = profile_objs[2]
        else:
            player_obj = profile_objs[game_state.selected_profile]
        player_obj.flip(1 if player_dir == 1 else 0)

    _move(dx, dy)
    _update_camera()

    col = int(player_x) // TILE
    row = int(player_y) // TILE

    # pantheon gate trigger
    if (GATE_COL <= col <= GATE_COL + GATE_W - 1 and
            GATE_ROW <= row <= GATE_ROW + GATE_H - 1):
        return "PANTHEON"

    return None

# =========================================================
# DRAW
# =========================================================
def draw_scene():
    draw.clear(0)

    # floor
    sc = cam_x // TILE;  sr = cam_y // TILE
    ec = min(MAP_W, sc + SCREEN_W//TILE + 2)
    er = min(MAP_H, sr + SCREEN_H//TILE + 2)

    for row in range(sr, er):
        for col in range(sc, ec):
            sx = col*TILE - cam_x
            sy = row*TILE - cam_y
            if _get(col, row) == 0:
                draw.filled_rect(sx, sy, TILE, TILE, COLOR_FLOOR)
            elif _get(col, row) == 1:
                draw.filled_rect(sx, sy, TILE, TILE, COLOR_WALL)
                draw.rect(sx+1, sy+1, TILE-2, TILE-2,
                          COLOR_WALL-1 if COLOR_WALL > 1 else COLOR_WALL)

    # boss silhouettes — drawn as simple bordered rectangles with number
    for sc2, sr2, label, col in SILHOUETTES:
        sx = sc2*TILE - cam_x
        sy = sr2*TILE - cam_y
        draw.filled_rect(sx, sy, TILE*2, TILE*2, 1)
        draw.rect(sx, sy, TILE*2, TILE*2, col)
        draw.rect(sx+2, sy+2, TILE*2-4, TILE*2-4, col)
        draw.text(label, sx + TILE - 2, sy + TILE - 4, col)

    # pantheon gate — pulsing gold portal
    gx = GATE_COL*TILE - cam_x
    gy = GATE_ROW*TILE - cam_y
    gw = GATE_W*TILE
    gh = GATE_H*TILE
    pulse = (gate_pulse // 8) % 4
    colors = [9, 14, 15, 14]
    gc = colors[pulse]
    draw.filled_rect(gx, gy, gw, gh, 1)
    draw.rect(gx,   gy,   gw,   gh,   gc)
    draw.rect(gx+2, gy+2, gw-4, gh-4, gc)
    # inner cross
    draw.line(gx + gw//2, gy+2, gx + gw//2, gy+gh-2, gc)
    draw.line(gx+2, gy + gh//2, gx+gw-2, gy + gh//2, gc)
    draw.text("P", gx + gw//2 - 2, gy + gh//2 - 4, 15)

    # player
    sx = int(player_x) - cam_x
    sy = int(player_y) - cam_y
    player_obj.pos_x = sx
    player_obj.pos_y = sy
    player_obj.draw()

    # HUD
    draw.text("ALL OF THE FIGHTERS", 88, 4, 9)
    draw.text("WEP:"+game_state.WEAPON_TYPE, 4, 4, 7)

    # gate hint when close
    col2 = int(player_x) // TILE
    row2 = int(player_y) // TILE
    if abs(col2 - GATE_COL) < 4 and abs(row2 - GATE_ROW) < 4:
        draw.text("ENTER PANTHEON", 96, 220, gc)