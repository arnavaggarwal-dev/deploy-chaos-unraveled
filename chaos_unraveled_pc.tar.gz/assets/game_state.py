# =========================================================
# SHARED GAME STATE
# All scenes read/write this module to pass data around.
# =========================================================

scene          = "SELECT"
result         = None

selected_profile = 0
spawn_x          = 32.0
spawn_y          = 32.0

# Weapon used in all boss fights — change this to swap weapon globally
# Options: "GUN" | "SWORD" | "TRIDENT" | "PICKAXE"
WEAPON_TYPE = "GUN"

# =========================================================
# KEY INVENTORY
# 9 keys total: 6 from map "2" tiles, 1 per boss cleared
# =========================================================
keys_collected  = 0      # total keys held (0-9)
boss1_key_given = False  # prevents double-awarding
boss2_key_given = False
boss3_key_given = False
boss4_key_given = False

# =========================================================
# DEBUG
# Set to True to skip key collection and open vault instantly
# =========================================================
DEBUG_UNLOCK_VAULT = True

# =========================================================
# PANTHEON
# Unlocks after all 4 bosses have been defeated at least once
# =========================================================
pantheon_unlocked  = False
pantheon_completed = False   # true after clearing all 4 in a row

