import random, math
from retroPy import *
import weapons
import game_state

# =========================================================
# SOCCER BOSS — boss2.rs8
# 40 HP, 3 independent attacks, 2 can run simultaneously
#
# ATK1 — POWER SHOT:  3 boll.rs8 projectiles in a cone
#                     each ball trails a manually drawn flame
# ATK2 — LASER GRID:  random lines drawn thin→thick
#                     damage zone activates when fully thick
# ATK3 — BLITZ LASER: phase 2 only (HP ≤ 20), faster/more
#                     lasers + tighter cone shots together
# =========================================================

# =========================================================
# WEAPONS
# =========================================================
WEAPON_TYPE = "GUN"   # fallback — overridden by game_state at runtime

gun     = weapons.Gun()
sword   = weapons.Sword()
trident = weapons.Trident()
pickaxe   = weapons.Pickaxe()
pimpillo  = weapons.Pimpillo()

wep_sprite = None   # set in _make_sprites

BOSS_HIT_CD  = 5
boss_hit_cd  = 0

# poison
poison_ticks = 0
poison_timer = 0
POISON_TICK_INTERVAL = 60

SCREEN_W = 320
SCREEN_H = 240
boss_obj   = None
player_obj = None

def _make_sprites():
    global boss_obj, player_obj, wep_sprite
    boss_obj   = gameObj("boss2.rs8",  160, 60, 200)
    player_obj = gameObj("sideclanker.rs8", 20, 180)
    player_obj.flip(1)
    wep_sprite = gameObj(
        "gun.rs8"     if WEAPON_TYPE == "GUN"     else
        "sword.rs8"   if WEAPON_TYPE == "SWORD"   else
        "trident.rs8" if WEAPON_TYPE == "TRIDENT" else
        "pickaxe.rs8"  if WEAPON_TYPE == "PICKAXE" else
        "pimpillo.rs8",
        -100, -100
    )

# =========================================================
# HEALTH / PHASE
# =========================================================
BOSS_MAX_HP   = 40
PLAYER_MAX_HP = 5
boss_hp       = 40
player_hp     = 5

INV_TIME  = 40
inv_timer = 0

phase2 = False    # unlocks ATK3 at HP ≤ 20

# =========================================================
# PLAYER
# =========================================================
player_x   = 20.0
player_y   = 180.0
player_dir = 1
PLAYER_SPD = 90

# =========================================================
# BALL PROJECTILE
# =========================================================
TRAIL_LEN   = 12
FLAME_COLS  = [9, 8, 2, 6]

# Degrees per frame the homing ball rotates toward the player.
# 2 = gentle curveball, 5 = tight hook, 10 = nearly tracks you
HOMING_STEER = 0.75

class Ball:
    def __init__(self, x, y, vx, vy, homing=False):
        self.x      = float(x)
        self.y      = float(y)
        self.speed  = math.sqrt(vx*vx + vy*vy)
        self.angle  = math.atan2(vy, vx)
        self.alive  = True
        self.homing = homing
        self.trail  = []

    def update(self, tx=0, ty=0):
        self.trail.append((self.x, self.y))
        if len(self.trail) > TRAIL_LEN:
            self.trail.pop(0)

        if self.homing:
            target_angle = math.atan2(ty - self.y, tx - self.x)
            diff = target_angle - self.angle
            diff = ((diff + math.pi) % (2 * math.pi)) - math.pi
            max_rot = math.radians(HOMING_STEER)
            self.angle += max(-max_rot, min(max_rot, diff))

        self.x += math.cos(self.angle) * self.speed
        self.y += math.sin(self.angle) * self.speed

        if self.x < -20 or self.x > SCREEN_W+20 or self.y < -20 or self.y > SCREEN_H+20:
            self.alive = False

    def draw_self(self):
        for i, (tx, ty) in enumerate(self.trail):
            t   = i / max(1, len(self.trail))
            col = FLAME_COLS[min(int(t * len(FLAME_COLS)), len(FLAME_COLS)-1)]
            r   = max(1, int(4 * t))
            draw.filled_rect(int(tx)-r//2, int(ty)-r//2, r, r, col)
        draw.filled_rect(int(self.x)-4, int(self.y)-4, 8, 8, 15)
        draw.circle(int(self.x), int(self.y), 5, 0)
        if self.homing:
            draw.filled_rect(int(self.x)-1, int(self.y)-1, 3, 3, 2)

# =========================================================
# ATK1 — POWER SHOT
# =========================================================
SHOT_CD      = 150
SHOT_SPD     = 3.0
CONE_SPREAD  = 0.8

shot_timer = 0
balls      = []

def fire_shots(bx, by, px, py, homing=False):
    angle = math.atan2(py - by, px - bx)
    for spread in (-CONE_SPREAD, 0, CONE_SPREAD):
        a  = angle + spread
        vx = math.cos(a) * SHOT_SPD
        vy = math.sin(a) * SHOT_SPD
        balls.append(Ball(bx, by, vx, vy, homing=homing))

# =========================================================
# ATK2 — LASER LINES
# =========================================================
LASER_CD         = 300
LASER_GROW_TIME  = 60
LASER_HOLD_TIME  = 20
LASER_MAX_W      = 8
LASER_DMG_W      = 7

class Laser:
    def __init__(self):
        edge = random.randint(0, 3)
        if edge == 0:    self.x1,self.y1 = random.randint(0,SCREEN_W), 0
        elif edge == 1:  self.x1,self.y1 = SCREEN_W, random.randint(0,SCREEN_H)
        elif edge == 2:  self.x1,self.y1 = random.randint(0,SCREEN_W), SCREEN_H
        else:            self.x1,self.y1 = 0, random.randint(0,SCREEN_H)

        edge2 = (edge + 2) % 4
        if edge2 == 0:   self.x2,self.y2 = random.randint(0,SCREEN_W), 0
        elif edge2 == 1: self.x2,self.y2 = SCREEN_W, random.randint(0,SCREEN_H)
        elif edge2 == 2: self.x2,self.y2 = random.randint(0,SCREEN_W), SCREEN_H
        else:            self.x2,self.y2 = 0, random.randint(0,SCREEN_H)

        self.timer  = 0
        self.phase  = "GROW"
        self.width  = 0

    def update(self):
        self.timer += 1
        if self.phase == "GROW":
            self.width = int(LASER_MAX_W * (self.timer / LASER_GROW_TIME))
            if self.timer >= LASER_GROW_TIME:
                self.phase = "HOLD";  self.timer = 0
        elif self.phase == "HOLD":
            self.width = LASER_MAX_W
            if self.timer >= LASER_HOLD_TIME:
                self.phase = "DEAD"

    def is_active(self):  return self.phase != "DEAD"
    def is_hot(self):     return self.width >= LASER_DMG_W

    def draw_self(self):
        if self.width <= 0:
            return
        col = 9 if self.phase == "GROW" else 2
        for off in range(-(self.width//2), self.width//2 + 1):
            draw.line(self.x1, self.y1 + off, self.x2, self.y2 + off, col)
            draw.line(self.x1 + off, self.y1, self.x2 + off, self.y2, col)

    def hits_point(self, px, py, margin=6):
        dx = self.x2 - self.x1;  dy = self.y2 - self.y1
        seg_len = max(1, math.sqrt(dx*dx + dy*dy))
        t = ((px - self.x1)*dx + (py - self.y1)*dy) / (seg_len * seg_len)
        t = max(0, min(1, t))
        cx = self.x1 + t*dx;  cy = self.y1 + t*dy
        dist = math.sqrt((px-cx)**2 + (py-cy)**2)
        return dist < self.width//2 + margin

laser_timer  = 0
lasers       = []

def spawn_lasers(count):
    for _ in range(count):
        lasers.append(Laser())

# =========================================================
# ATK3 — BLITZ (phase 2 only)
# =========================================================
BLITZ_CD    = 400
blitz_timer = 0

def fire_blitz(bx, by, px, py):
    angle = math.atan2(py - by, px - bx)
    for i in range(5):
        spread = -CONE_SPREAD + i * (CONE_SPREAD / 2)
        a  = angle + spread
        vx = math.cos(a) * (SHOT_SPD * 1.5)
        vy = math.sin(a) * (SHOT_SPD * 1.5)
        balls.append(Ball(bx, by, vx, vy, homing=True))
    spawn_lasers(4)

# =========================================================
# BOSS WANDER
# =========================================================
BOSS_SPD      = 35
boss_target_x = 160.0
boss_target_y = 80.0
wander_timer  = 0
WANDER_CD     = 110

# =========================================================
# DAMAGE
# =========================================================
def try_hit_player(dmg):
    global player_hp, inv_timer
    if inv_timer == 0:
        player_hp = max(0, player_hp - dmg)
        inv_timer = INV_TIME

def try_hit_boss(dmg):
    global boss_hp, boss_hit_cd
    if boss_hit_cd == 0:
        boss_hp     = max(0, boss_hp - dmg)
        boss_hit_cd = BOSS_HIT_CD

# =========================================================
# INIT
# =========================================================
def init():
    global boss_hp, player_hp, inv_timer, phase2
    global shot_timer, laser_timer, blitz_timer, wander_timer
    global boss_target_x, boss_target_y
    global player_x, player_y, player_dir
    global boss_hit_cd, poison_ticks, poison_timer
    global WEAPON_TYPE
    WEAPON_TYPE = game_state.WEAPON_TYPE   # pick up weapon chosen on map

    boss_hp    = BOSS_MAX_HP
    player_hp  = PLAYER_MAX_HP
    inv_timer  = 0
    phase2     = False

    shot_timer  = SHOT_CD
    laser_timer = int(LASER_CD // 1.5)
    blitz_timer = BLITZ_CD

    wander_timer  = 0
    boss_target_x = 160.0
    boss_target_y = 80.0

    player_x   = 20.0
    player_y   = 180.0
    player_dir = 1

    balls.clear()
    lasers.clear()

    gun.bullets.clear()
    gun.ammo         = gun.max_ammo
    gun.reload_timer = 0
    sword.timer      = 0
    trident.timer    = 0;  trident.vfx = 0
    pickaxe.timer    = 0
    pimpillo.active     = False
    pimpillo.zone_active = False
    pimpillo.cooldown    = 0

    boss_hit_cd  = 0
    poison_ticks = 0
    poison_timer = 0

    _make_sprites()

# =========================================================
# UPDATE — returns "WIN", "LOSE", or None
# =========================================================
def update():
    global boss_hp, player_hp, inv_timer, phase2
    global shot_timer, laser_timer, blitz_timer, wander_timer
    global boss_target_x, boss_target_y
    global player_x, player_y, player_dir
    global boss_hit_cd, poison_ticks, poison_timer

    if inv_timer   > 0: inv_timer   -= 1
    if boss_hit_cd > 0: boss_hit_cd -= 1

    # poison ticks (bypass boss hit cooldown)
    if poison_ticks > 0:
        poison_timer -= 1
        if poison_timer <= 0:
            boss_hp      = max(0, boss_hp - 1)
            poison_ticks -= 1
            poison_timer  = POISON_TICK_INTERVAL if poison_ticks > 0 else 0

    # ---- phase check ----
    if boss_hp <= 20 and not phase2:
        phase2 = True

    # ---- player movement ----
    spd = PLAYER_SPD * dt()
    dx = 0.0;  dy = 0.0
    if kb.read_left()  == 0:
        dx = -spd
        if player_dir != -1:
            player_dir = -1;  player_obj.flip(0)
    if kb.read_right() == 0:
        dx = spd
        if player_dir != 1:
            player_dir = 1;  player_obj.flip(1)
    if kb.read_up()   == 0:  dy = -spd
    if kb.read_down() == 0:  dy =  spd
    if dx != 0 and dy != 0:
        dx *= 0.707;  dy *= 0.707

    player_x = max(0, min(player_x + dx, SCREEN_W - 12))
    player_y = max(0, min(player_y + dy, SCREEN_H - 12))
    player_obj.pos_x = int(player_x)
    player_obj.pos_y = int(player_y)

    px = int(player_x);  py = int(player_y)

    # ---- weapon input ----
    if kb.B_down():
        if   WEAPON_TYPE == "GUN":      gun.shoot(px, py, player_dir)
        elif WEAPON_TYPE == "SWORD":    sword.attack()
        elif WEAPON_TYPE == "TRIDENT":  trident.attack()
        elif WEAPON_TYPE == "PICKAXE":  pickaxe.attack()
        elif WEAPON_TYPE == "PIMPILLO": pimpillo.attack(px, py, player_dir)

    gun.update();  sword.update();  trident.update();  pickaxe.update();  pimpillo.update()

    bx2 = int(boss_obj.pos_x);  by2 = int(boss_obj.pos_y)

    # ---- weapon damage ----
    wx = px + 5

    for b in gun.bullets:
        if boss_obj.colliderPt(int(b.x), int(b.y)):
            try_hit_boss(weapons.Gun.DAMAGE);  b.alive = False

    if WEAPON_TYPE == "SWORD" and sword.is_busy():
        for hx, hy in sword.hit_points(wx, py, player_dir):
            if boss_obj.colliderPt(hx, hy):
                try_hit_boss(weapons.Sword.DAMAGE);  break

    if WEAPON_TYPE == "PICKAXE" and pickaxe.timer > 0:
        for hx, hy in pickaxe.hit_points(wx, py, player_dir):
            if boss_obj.colliderPt(hx, hy):
                try_hit_boss(weapons.Pickaxe.DAMAGE);  break

    if WEAPON_TYPE == "TRIDENT" and trident.timer > 0:
        for hx, hy in trident.hit_points(wx, py, player_dir):
            if boss_obj.colliderPt(hx, hy):
                try_hit_boss(weapons.Trident.DAMAGE)
                poison_ticks = weapons.Trident.POISON_TICKS
                poison_timer = POISON_TICK_INTERVAL
                break

    if WEAPON_TYPE == "PIMPILLO":
        pimpillo.hit_enemy(lambda hx, hy: boss_obj.colliderPt(hx, hy))
        for hx, hy in pimpillo.zone_hit_points():
            if boss_obj.colliderPt(hx, hy):
                try_hit_boss(weapons.Pimpillo.DAMAGE);  break

    # ---- boss wander ----
    bx = int(boss_obj.pos_x);  by = int(boss_obj.pos_y)
    wander_timer += 1
    if wander_timer >= WANDER_CD:
        wander_timer  = 0
        boss_target_x = float(random.randint(40, SCREEN_W - 40))
        boss_target_y = float(random.randint(20, SCREEN_H // 2))

    wdx = boss_target_x - bx;  wdy = boss_target_y - by
    wd  = max(1, math.sqrt(wdx*wdx + wdy*wdy))
    if wd > 3:
        boss_obj.speed_x = (wdx/wd) * BOSS_SPD
        boss_obj.speed_y = (wdy/wd) * BOSS_SPD
    else:
        boss_obj.speed_x = 0;  boss_obj.speed_y = 0

    boss_obj.clamp_x(10, SCREEN_W - 30)
    boss_obj.clamp_y(10, SCREEN_H // 2)
    boss_obj.update()

    bx = int(boss_obj.pos_x);  by = int(boss_obj.pos_y)

    # ---- ATK1: power shot ----
    shot_timer += 1
    if shot_timer >= SHOT_CD:
        shot_timer = 0
        fire_shots(bx, by, px, py, homing=phase2)

    # ---- ATK2: laser lines ----
    laser_timer += 1
    if laser_timer >= LASER_CD:
        laser_timer = 0
        spawn_lasers(2 if not phase2 else 3)

    # ---- ATK3: blitz (phase 2 only) ----
    if phase2:
        blitz_timer += 1
        if blitz_timer >= BLITZ_CD:
            blitz_timer = 0
            fire_blitz(bx, by, px, py)

    # ---- update balls ----
    i = 0
    while i < len(balls):
        b = balls[i]
        b.update(px, py)
        if not b.alive:
            balls.pop(i)
        else:
            if player_obj.colliderPt(int(b.x), int(b.y)):
                try_hit_player(1)
                balls.pop(i)
            else:
                i += 1

    # ---- update lasers + damage ----
    i = 0
    while i < len(lasers):
        l = lasers[i]
        l.update()
        if not l.is_active():
            lasers.pop(i)
        else:
            if l.is_hot() and l.hits_point(int(player_obj.mid_x), int(player_obj.mid_y)):
                try_hit_player(1)
            i += 1

    if boss_hp <= 0:   return "WIN"
    if player_hp <= 0: return "LOSE"
    return None

# =========================================================
# DRAW
# =========================================================
def draw_scene():
    draw.clear(0)

    for l in lasers:
        l.draw_self()

    for b in balls:
        b.draw_self()

    boss_obj.draw()
    player_obj.draw()

    px = int(player_x);  py = int(player_y)

    if wep_sprite:
        wep_sprite.pos_x = px + 5;  wep_sprite.pos_y = py
        wep_sprite.draw()
    gun.draw(draw)
    sword.draw(draw,   px + 5, py, player_dir)
    trident.draw(draw, px + 5, py, player_dir)
    pickaxe.draw(draw, px + 5, py, player_dir)
    pimpillo.draw(draw)

    bx = int(boss_obj.pos_x);  by = int(boss_obj.pos_y)

    # boss HP bar
    draw.filled_rect(bx - 30, by - 16, 60, 5, 7)
    draw.filled_rect(bx - 30, by - 16, int(60 * (boss_hp / BOSS_MAX_HP)), 5, 2)
    if phase2:
        draw.text("PHASE 2", bx - 20, by - 24, 9)

    # player HP
    draw.filled_rect(4, 4, 60, 5, 7)
    draw.filled_rect(4, 4, int(60 * (player_hp / PLAYER_MAX_HP)), 5, 3)

    # debug
    draw.text("HP:"+str(boss_hp)+" P2:"+str(phase2), 200, 4, 15)
    homing_count = sum(1 for b in balls if b.homing)
    draw.text("HOM:"+str(homing_count)+"/"+str(len(balls)), 200, 12, 9)

    # ATK cooldown pips
    shot_pct  = min(1.0, shot_timer  / SHOT_CD)
    laser_pct = min(1.0, laser_timer / LASER_CD)
    draw.filled_rect(4,  14, 40, 3, 7)
    draw.filled_rect(4,  14, int(40 * shot_pct),  3, 9)
    draw.filled_rect(4,  20, 40, 3, 7)
    draw.filled_rect(4,  20, int(40 * laser_pct), 3, 6)

    if phase2:
        blitz_pct = min(1.0, blitz_timer / BLITZ_CD)
        draw.filled_rect(4, 26, 40, 3, 7)
        draw.filled_rect(4, 26, int(40 * blitz_pct), 3, 2)