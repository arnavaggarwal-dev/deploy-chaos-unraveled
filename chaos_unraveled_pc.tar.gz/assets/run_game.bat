@echo off
echo Chaos Unraveled - PC Port
echo.

REM Check Python version
python --version 2>nul
if errorlevel 1 (
    echo ERROR: Python not found. Install Python 3.9+ from https://python.org
    pause
    exit /b
)

REM Try to import pygame - if it fails, install it
python -c "import pygame" 2>nul
if errorlevel 1 (
    echo pygame not found. Installing...
    echo.
    REM Try pygame-ce first (supports Python 3.12, 3.13, 3.14 with pre-built wheels)
    pip install pygame-ce --quiet
    if errorlevel 1 (
        REM Fall back to classic pygame
        pip install pygame --quiet
    )
    REM Verify install worked
    python -c "import pygame" 2>nul
    if errorlevel 1 (
        echo.
        echo ERROR: Could not install pygame automatically.
        echo Please run one of these manually, then try again:
        echo   pip install pygame-ce
        echo   pip install pygame
        pause
        exit /b
    )
    echo pygame installed successfully!
    echo.
)

echo Controls:
echo   Arrow Keys = Move / Menu
echo   Z          = A button  (confirm / attack)
echo   X          = B button  (hold Up+X on map for Boss 2)
echo   Q          = Left Shoulder  (exit sub-map)
echo   ESC        = Quit
echo.

cd /d "%~dp0"
python main.py
pause
