import math

# =========================================================
# BULLET
# =========================================================
class Bullet:
    def __init__(self, x, y, direction=1):
        self.x     = x
        self.y     = y
        self.speed = 6
        self.alive = True
        self.dir   = direction

    def update(self):
        self.x += self.speed * self.dir
        if self.x > 320 or self.x < 0:
            self.alive = False

    def draw(self, draw):
        draw.filled_rect(int(self.x), int(self.y), 4, 2, 9)


# =========================================================
# GUN
# =========================================================
class Gun:
    DAMAGE = 1   # damage per bullet

    def __init__(self):
        self.max_ammo     = 10
        self.ammo         = 10
        self.reload_time  = 300
        self.reload_timer = 0
        self.bullets      = []

    def shoot(self, x, y, direction=1):
        if self.reload_timer > 0:
            return
        if self.ammo > 0:
            self.bullets.append(Bullet(x, y, direction))
            self.ammo -= 1
        if self.ammo <= 0:
            self.reload_timer = self.reload_time

    def update(self):
        if self.reload_timer > 0:
            self.reload_timer -= 1
            if self.reload_timer == 0:
                self.ammo = self.max_ammo

        i = 0
        while i < len(self.bullets):
            b = self.bullets[i]
            b.update()
            if not b.alive:
                self.bullets.pop(i)
            else:
                i += 1

    def draw(self, draw):
        for b in self.bullets:
            b.draw(draw)

    def reload_progress(self):
        if self.reload_timer == 0:
            return self.max_ammo
        return int(self.max_ammo * (1 - self.reload_timer / self.reload_time))


# =========================================================
# MELEE BASE
# FIX: attack() now blocked while timer > 0 so you can't
# cancel or restart an attack mid-swing
# =========================================================
class MeleeWeapon:
    DAMAGE = 1   # override in subclasses

    def __init__(self, timer_len, radius, color):
        self.timer_len = timer_len
        self.timer     = 0
        self.radius    = radius
        self.color     = color

    def attack(self):
        # FIX: block new attack until current one finishes
        if self.timer > 0:
            return
        self.timer = self.timer_len

    def update(self):
        if self.timer > 0:
            self.timer -= 1

    def draw(self, draw, x, y, direction=1):
        if self.timer <= 0:
            return
        t         = 1 - (self.timer / self.timer_len)
        sweep_end = int(-80 + 160 * t)
        for a in range(-80, min(sweep_end, 80), 8):
            da = a if direction == 1 else 180 - a
            px = x + int(math.cos(math.radians(da)) * self.radius)
            py = y + int(math.sin(math.radians(da)) * self.radius)
            draw.filled_rect(px, py, 2, 2, self.color)

    def hit_points(self, x, y, direction=1):
        """Returns all arc points to test for collision this frame."""
        if self.timer <= 0:
            return []
        t         = 1 - (self.timer / self.timer_len)
        sweep_end = int(-80 + 160 * t)
        pts = []
        for a in range(-80, min(sweep_end, 80), 8):
            da = a if direction == 1 else 180 - a
            pts.append((
                x + int(math.cos(math.radians(da)) * self.radius),
                y + int(math.sin(math.radians(da)) * self.radius),
            ))
        return pts


# =========================================================
# SWORD — double slash
# Slash 1: sweeps -80 -> +80 (color 9, cyan)
# Gap:     8 frame pause between swings
# Slash 2: sweeps +80 -> -80 (color 11, green), reversed arc
# FIX: can't start a new attack until both slashes + gap finish
# FIX: radius increased from 20 -> 36
# =========================================================
class Sword(MeleeWeapon):
    GAP_LEN = 8
    DAMAGE  = 2   # per slash (fires twice = 4 total per full attack)

    def __init__(self):
        super().__init__(timer_len=20, radius=36, color=9)
        self.slash     = 0   # 1 = first, 2 = second
        self.gap_timer = 0

    def is_busy(self):
        return self.timer > 0 or self.gap_timer > 0

    def attack(self):
        if self.is_busy():
            return
        self.timer = self.timer_len
        self.slash = 1

    def update(self):
        if self.timer > 0:
            self.timer -= 1
            # first slash finished — start gap before second
            if self.timer == 0 and self.slash == 1:
                self.gap_timer = self.GAP_LEN

        if self.gap_timer > 0:
            self.gap_timer -= 1
            # gap finished — fire second slash
            if self.gap_timer == 0 and self.slash == 1:
                self.timer = self.timer_len
                self.slash = 2

    def draw(self, draw, x, y, direction=1):
        if self.timer <= 0:
            return
        t = 1 - (self.timer / self.timer_len)
        if self.slash == 1:
            sweep_end = int(-80 + 160 * t)
            for a in range(-80, min(sweep_end, 80), 8):
                da = a if direction == 1 else 180 - a
                px = x + int(math.cos(math.radians(da)) * self.radius)
                py = y + int(math.sin(math.radians(da)) * self.radius)
                draw.filled_rect(px, py, 2, 2, 9)
        else:
            sweep_end = int(80 - 160 * t)
            for a in range(80, max(sweep_end, -80), -8):
                da = a if direction == 1 else 180 - a
                px = x + int(math.cos(math.radians(da)) * self.radius)
                py = y + int(math.sin(math.radians(da)) * self.radius)
                draw.filled_rect(px, py, 2, 2, 11)

    def hit_points(self, x, y, direction=1):
        if self.timer <= 0:
            return []
        t   = 1 - (self.timer / self.timer_len)
        pts = []
        if self.slash == 1:
            sweep_end = int(-80 + 160 * t)
            for a in range(-80, min(sweep_end, 80), 8):
                da = a if direction == 1 else 180 - a
                pts.append((x + int(math.cos(math.radians(da)) * self.radius),
                            y + int(math.sin(math.radians(da)) * self.radius)))
        else:
            sweep_end = int(80 - 160 * t)
            for a in range(80, max(sweep_end, -80), -8):
                da = a if direction == 1 else 180 - a
                pts.append((x + int(math.cos(math.radians(da)) * self.radius),
                            y + int(math.sin(math.radians(da)) * self.radius)))
        return pts


# =========================================================
# PICKAXE
# FIX: radius increased from 40 -> 55
# FIX: inherits attack-blocking from MeleeWeapon
# =========================================================
class Pickaxe(MeleeWeapon):
    DAMAGE = 3
    def __init__(self):
        super().__init__(timer_len=15, radius=55, color=6)


# =========================================================
# TRIDENT
# FIX: attack blocked while timer > 0
# FIX: hitbox range increased from 60 -> 80
# =========================================================
class Trident:
    HIT_RANGE_X  = 80
    HIT_RANGE_Y  = 28
    DAMAGE       = 3   # direct hit damage
    POISON_TICKS = 3   # number of poison ticks applied on hit
    POISON_DMG   = 1   # damage per poison tick

    def __init__(self):
        self.timer = 0
        self.vfx   = 0

    def attack(self):
        # FIX: block new attack until current one finishes
        if self.timer > 0:
            return
        self.timer = 15
        self.vfx   = 12

    def update(self):
        if self.timer > 0: self.timer -= 1
        if self.vfx   > 0: self.vfx   -= 1

    def draw(self, draw, x, y, direction=1):
        if self.timer > 0:
            ex = x + (20 * direction)
            draw.line(x, y, ex, y, 9)

        if self.vfx > 0:
            t     = 1 - (self.vfx / 12)
            end_a = int(-30 + 60 * t)
            shade = 10 if self.vfx % 2 == 0 else 7
            for a in range(-30, end_a, 6):
                da = a if direction == 1 else 180 - a
                px = x + int(math.cos(math.radians(da)) * 25)
                py = y + int(math.sin(math.radians(da)) * 25)
                draw.filled_rect(px, py, 2, 2, shade)

    def hit_points(self, x, y, direction=1):
        """Sweep points along the full trident line, not just the tip."""
        if self.timer <= 0:
            return []
        pts = []
        for step in range(0, self.HIT_RANGE_X + 1, 8):
            pts.append((x + step * direction, y))
        return pts


# =========================================================
# PIMPILLO — Sprout-style lobbed projectile
#
# Lobs an arc toward the facing direction.
# On landing creates a bush zone that lingers for
# ZONE_DURATION frames and damages enemies that enter it.
#
# Usage (per boss file):
#   pimpillo = Pimpillo()
#   pimpillo.attack(px, py, direction)   # fire
#   pimpillo.update()                    # each frame
#   pimpillo.draw(draw)                  # each frame
#   pimpillo.zone_hit_points()           # list of (x,y) to collide-test
# =========================================================
class Pimpillo:
    DAMAGE        = 1
    ZONE_RANGE    = 27
    ZONE_DURATION = 40
    SHOT_COOLDOWN = 231  # 7 seconds at 33fps
    MAX_BOUNCES   = 3
    SCREEN_W      = 320
    SCREEN_H      = 240
    # speed in pixels per frame
    SPEED         = 5.0
    # gravity added to vy each frame to make it arc downward
    GRAVITY       = 0.18

    def __init__(self):
        self.active      = False
        self.proj_x      = 0.0
        self.proj_y      = 0.0
        self.vx          = 0.0   # velocity x
        self.vy          = 0.0   # velocity y
        self.bounces     = 0
        self.zone_active = False
        self.zone_x      = 0
        self.zone_y      = 0
        self.zone_timer  = 0
        self.cooldown    = 0

    def is_busy(self):
        return self.active or self.zone_active or self.cooldown > 0

    def attack(self, px, py, direction=1):
        if self.is_busy():
            return
        self.active  = True
        self.proj_x  = float(px)
        self.proj_y  = float(py)
        self.vx      = self.SPEED * direction
        self.vy      = -3.5   # initial upward kick for arc
        self.bounces = 0

    def _land(self):
        self.active      = False
        self.zone_active = True
        self.zone_x      = int(self.proj_x)
        self.zone_y      = int(self.proj_y)
        self.zone_timer  = self.ZONE_DURATION

    def update(self):
        if self.cooldown > 0:
            self.cooldown -= 1

        if self.active:
            self.vy     += self.GRAVITY
            self.proj_x += self.vx
            self.proj_y += self.vy

            # bounce off all 4 edges
            if self.proj_x <= 0:
                self.proj_x  = 0.0
                self.vx      = abs(self.vx)
                self.bounces += 1
            elif self.proj_x >= self.SCREEN_W:
                self.proj_x  = float(self.SCREEN_W)
                self.vx      = -abs(self.vx)
                self.bounces += 1

            if self.proj_y <= 0:
                self.proj_y  = 0.0
                self.vy      = abs(self.vy) * 0.75
                self.bounces += 1
            elif self.proj_y >= self.SCREEN_H:
                self.proj_y  = float(self.SCREEN_H)
                self.vy      = -abs(self.vy) * 0.75
                self.bounces += 1

            # land only when bounce limit exceeded
            if self.bounces >= self.MAX_BOUNCES:
                self._land()

        self._tick_zone()

    def hit_enemy(self, collider_fn):
        """Call with a function that returns True if ball hits something.
        Triggers immediate explosion (land) on contact even before bounces used up."""
        if self.active and collider_fn(int(self.proj_x), int(self.proj_y)):
            self._land()
            return True
        return False

    def _tick_zone(self):
        if self.zone_active:
            self.zone_timer -= 1
            if self.zone_timer <= 0:
                self.zone_active = False
                self.cooldown    = self.SHOT_COOLDOWN

    def draw(self, draw):
        if self.active:
            sx = int(self.proj_x)
            sy = int(self.proj_y)
            # shadow on floor directly below ball
            shadow_y = min(self.SCREEN_H - 2, self.SCREEN_H)
            draw.circle(sx, shadow_y, 4, 5)
            # ball — layered for visibility
            draw.filled_rect(sx - 5, sy - 5, 11, 11, 10)
            draw.filled_rect(sx - 3, sy - 3,  7,  7,  3)
            draw.filled_rect(sx - 1, sy - 1,  3,  3, 15)
            # bounce count indicator dots above ball
            for i in range(self.MAX_BOUNCES - self.bounces):
                draw.filled_rect(sx - 4 + i * 6, sy - 10, 4, 4, 9)

        if self.zone_active:
            zx  = self.zone_x
            zy  = self.zone_y
            r   = self.ZONE_RANGE
            col = 3 if (self.zone_timer // 6) % 2 == 0 else 10
            draw.circle(zx, zy, r,     col)
            draw.circle(zx, zy, r - 6, col)
            for a in range(0, 360, 45):
                rad = math.radians(a)
                lx  = zx + int(math.cos(rad) * (r - 2))
                ly  = zy + int(math.sin(rad) * (r - 2))
                draw.filled_rect(lx - 1, ly - 1, 3, 3, 3)

        if self.cooldown > 0:
            pct = 1.0 - (self.cooldown / self.SHOT_COOLDOWN)
            draw.filled_rect(4, 36, 60, 3, 5)
            draw.filled_rect(4, 36, int(60 * pct), 3, 10)

    def zone_hit_points(self):
        if not self.zone_active:
            return []
        pts = []
        for a in range(0, 360, 45):
            rad = math.radians(a)
            pts.append((
                self.zone_x + int(math.cos(rad) * (self.ZONE_RANGE // 2)),
                self.zone_y + int(math.sin(rad) * (self.ZONE_RANGE // 2)),
            ))
        pts.append((self.zone_x, self.zone_y))
        return pts