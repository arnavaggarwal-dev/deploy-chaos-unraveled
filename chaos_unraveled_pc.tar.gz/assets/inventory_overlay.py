import math
from retroPy import *
import game_state

# =========================================================
# INVENTORY OVERLAY
# Shows on top of any scene when A + UP + B held together.
# Adapts the left-screen inventory code to run on the
# main 320x240 screen as an overlay panel.
# No disp.init — uses the existing display.
#
# Weapon snapped to slot → updates game_state.WEAPON_TYPE
# Keys shown reflect game_state.keys_collected
# =========================================================

# =========================================================
# SPRITES
# =========================================================
cursor    = gameObj("cursor.rs8",         116, 104)
gun       = gameObj("gun.rs8",             90, 184)
trident   = gameObj("trident.rs8",        130, 184)
sword     = gameObj("sword.rs8",          170, 184)
pkaxe     = gameObj("pickaxe.rs8",        210, 184)
pimpillo  = gameObj("pimpillo.rs8",       250, 184)
bgclanker = gameObj("smoothclanker.rs8",   60,  50, 300)

items          = [gun, trident, sword, pkaxe, pimpillo]
base_positions = [(item.pos_x, item.pos_y) for item in items]

WEAPON_NAMES = ["GUN", "TRIDENT", "SWORD", "PICKAXE", "PIMPILLO"]

keycount = 9
center_x = 30
center_y = 190
radius   = 30
rotation = 0.0

keys = [None] * keycount

def _build_keys():
    global keys
    collected = game_state.keys_collected
    for i in range(keycount):
        unlocked = i < collected
        if unlocked and keys[i] is None:
            angle = (i / keycount) * 360 + rotation
            rad   = math.radians(angle)
            x     = int(center_x + radius * math.cos(rad))
            y     = int(center_y + radius * math.sin(rad))
            try:
                k = gameObj("key" + str(i+1) + ".rs8", x, y)
                k.flip(3)
                keys[i] = k
            except:
                keys[i] = None   # sprite missing, skip silently
        elif not unlocked:
            keys[i] = None

# =========================================================
# EQUIP SLOT
# =========================================================
held_item     = None
snap_x        = 20
snap_y        = 40
snap_range    = 20
snapped_index = None
prev_snapped  = None

# =========================================================
# MESSAGES
# =========================================================
show_key_msg = False
show_gun_msg = False
show_tri_msg = False
show_swd_msg = False
show_pkx_msg = False
show_pmp_msg = False

cc = 0

# =========================================================
# OPEN / CLOSE
# =========================================================
is_open = False

def open_overlay():
    global is_open, held_item, prev_snapped
    is_open     = True
    held_item   = None
    prev_snapped = snapped_index
    _build_keys()

def close_overlay():
    global is_open, held_item
    is_open   = False
    held_item = None
    # park cursor off-screen so it doesn't bleed
    cursor.pos_x = 1000
    cursor.pos_y = 1000

# =========================================================
# CURSOR MOVEMENT — uses right/left/B to move, not A
# (A is reserved for the combo trigger check in main.py)
# =========================================================
def _curmove():
    if kb.right_down(): cursor.speed_x =  150
    elif kb.right_up(): cursor.speed_x =  0
    if kb.left_down():  cursor.speed_x = -150
    elif kb.left_up():  cursor.speed_x =  0
    if kb.down_down():     cursor.speed_y =  150
    elif kb.down_up():     cursor.speed_y =  0
    if kb.up_down(): cursor.speed_y =  -150
    elif kb.up_up(): cursor.speed_y =  0
    if cursor.pos_y >= 230: cursor.pos_y = 0
    cursor.clamp_x(0, 310)

# =========================================================
# UPDATE — call every frame from main.py when open
# =========================================================
def update():
    global cc, snapped_index, prev_snapped, rotation
    global held_item
    global show_key_msg, show_gun_msg, show_tri_msg, show_swd_msg, show_pkx_msg, show_pmp_msg

    cc += 1
    t = cc * 0.06
    bgclanker.pos_x = 60 + int(math.sin(t) * 60)

    # grab on A press
    if kb.A_down():
        for item in items:
            if item.collider(cursor):
                held_item = item
                break

    # release on A up — snap if near slot
    if kb.A_up():
        if held_item is not None:
            for i, item in enumerate(items):
                if item == held_item:
                    if (abs(cursor.pos_x - snap_x) < snap_range and
                            abs(cursor.pos_y - snap_y) < snap_range):
                        snapped_index = i
                    break
        held_item = None

    # position items
    for i, item in enumerate(items):
        base_x, base_y = base_positions[i]
        if item == held_item:
            item.pos_x = cursor.pos_x
            item.pos_y = cursor.pos_y
        elif snapped_index == i:
            item.pos_x = snap_x
            item.pos_y = snap_y
        else:
            item.pos_x = base_x
            item.pos_y = base_y

    # update game_state weapon when snap changes
    if snapped_index is not None and snapped_index != prev_snapped:
        game_state.WEAPON_TYPE = WEAPON_NAMES[snapped_index]
    prev_snapped = snapped_index

    # rotate keys
    for i in range(keycount):
        if keys[i] is None:
            continue
        angle     = (i / keycount) * 360 + rotation
        rad       = math.radians(angle)
        keys[i].pos_x = int(center_x + radius * math.cos(rad))
        keys[i].pos_y = int(center_y + radius * math.sin(rad))
    rotation += 0.7

    _curmove()

    # collision flags
    show_key_msg = False
    for k in keys:
        if k is not None and cursor.collider(k):
            show_key_msg = True
            break
    show_gun_msg  = cursor.collider(gun)
    show_tri_msg  = cursor.collider(trident)
    show_swd_msg  = cursor.collider(sword)
    show_pkx_msg  = cursor.collider(pkaxe)
    show_pmp_msg  = cursor.collider(pimpillo)

    cursor.update()
    bgclanker.update()

# =========================================================
# DRAW — draws the inventory panel over whatever is below
# =========================================================
def draw_scene():
    # semi-transparent dark panel over the game
    draw.filled_rect(0, 0, 320, 240, 0)

    draw.text("INVENTORY", 130, 10, 15)
    draw.text("Equipped:", 15, 30, 9)

    # equip slot
    slot_col = 10 if (snapped_index is not None) else 12
    draw.rect(20, 40, 20, 20, slot_col)
    if snapped_index is not None:
        draw.text(WEAPON_NAMES[snapped_index], 4, 62, 9)

    # weapon tray boxes
    for i in range(5):
        draw.rect(85 + i*40, 179, 25, 25, 12)
    for i in range(4):
        draw.filled_rect(110 + (i*40), 179, 15, 25, 12)

    bgclanker.draw()

    # keys
    for key in keys:
        if key is not None:
            key.draw()

    # key count
    draw.text("KEYS:" + str(game_state.keys_collected) + "/9", 200, 185, 14)

    # messages
    if show_key_msg: _disp_key_msg()
    if show_gun_msg: _disp_gun_msg()
    if show_tri_msg: _disp_tri_msg()
    if show_swd_msg: _disp_swd_msg()
    if show_pkx_msg: _disp_pkx_msg()
    if show_pmp_msg: _disp_pmp_msg()

    # collider debug
    for key in keys:
        if key is not None and cursor.collider(key):
            key.drawCollider(4)
    for item in items:
        if cursor.collider(item):
            item.drawCollider(2)

    gun.draw();  trident.draw();  sword.draw();  pkaxe.draw();  pimpillo.draw()
    cursor.draw()

    draw.text("Hold A+UP+B to close", 80, 225, 5)

# =========================================================
# MESSAGE HELPERS
# =========================================================
def _disp_key_msg():
    draw.filled_rect(55, 50, 130, 70, 1)
    draw.text("this is an",     60, 68, 9)
    draw.text("enchanted key",  60, 78, 9)

def _disp_gun_msg():
    draw.filled_rect(55, 50, 130, 70, 1)
    draw.text("this is an",     60, 62, 9)
    draw.text("oddly modern",   60, 72, 9)
    draw.text("gun",            60, 82, 9)

def _disp_tri_msg():
    draw.filled_rect(55, 50, 130, 70, 1)
    draw.text("A shimmering",   60, 62, 9)
    draw.text("trident, made",  60, 72, 9)
    draw.text("of Orichalcum",  60, 82, 9)

def _disp_swd_msg():
    draw.filled_rect(55, 50, 130, 70, 1)
    draw.text("A shiny",        60, 62, 9)
    draw.text("sword, made",    60, 72, 9)
    draw.text("of Valkrium",    60, 82, 9)

def _disp_pkx_msg():
    draw.filled_rect(55, 50, 130, 70, 1)
    draw.text("A rusty",        60, 68, 9)
    draw.text("pickaxe",        60, 78, 9)

def _disp_pmp_msg():
    draw.filled_rect(55, 50, 130, 70, 1)
    draw.text("Pimpillo",       60, 62, 9)
    draw.text("Lobbed bomb,",   60, 72, 9)
    draw.text("bounces x2",     60, 82, 9)