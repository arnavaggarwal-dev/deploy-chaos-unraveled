"""
retroPy.py  —  pygame compatibility shim for Chaos Unraveled (PC port)

Emulates the retroPy MicroPython game engine API so the original game
files run unchanged on Windows/Mac/Linux with Python + pygame.

Controls:
  Arrow keys        = D-pad
  Z                 = A button
  X                 = B button
  Q / Left-Shift    = T-left (shoulder)
  E                 = T-right (shoulder)
  ESC               = quit
"""

import pygame
import struct
import os
import time
import asyncio

# ---------------------------------------------------------------------------
# PICO-8  16-colour palette  (index → RGB)
# ---------------------------------------------------------------------------
PALETTE = [
    (0,   0,   0),    # 0  black
    (29,  43,  83),   # 1  dark blue
    (126, 37,  83),   # 2  dark purple
    (0,   135, 81),   # 3  dark green
    (171, 82,  54),   # 4  brown
    (95,  87,  79),   # 5  dark grey
    (194, 195, 199),  # 6  light grey
    (255, 241, 232),  # 7  white
    (255, 0,   77),   # 8  red
    (255, 163, 0),    # 9  orange
    (255, 236, 39),   # 10 yellow
    (0,   228, 54),   # 11 green
    (41,  173, 255),  # 12 blue
    (131, 118, 156),  # 13 lavender
    (255, 119, 168),  # 14 pink
    (255, 204, 170),  # 15 peach
]

def _pal(idx):
    """Return (R,G,B) for a palette index, clamping to valid range."""
    return PALETTE[int(idx) % 16]

# ---------------------------------------------------------------------------
# Global pygame state (initialised lazily by gameloop)
# ---------------------------------------------------------------------------
SCREEN_W = 320
SCREEN_H = 240
SCALE    = 3          # display 3× for a comfortable window

_surface  = None      # 320×240 logical surface
_display  = None      # scaled display surface
_clock    = None
_font     = None      # 8×8 pixel font
_fps      = 60
_dt       = 1.0 / _fps   # current delta time in seconds

_sprite_cache: dict = {}   # path → list[pygame.Surface]  (one per frame)

def _get_surface():
    return _surface

# ---------------------------------------------------------------------------
# RS8 sprite loader
# ---------------------------------------------------------------------------
# Header layout (16 bytes total before pixel data):
#   Byte 0        : magic 'R'
#   Bytes 1-2     : width  (uint16 LE)
#   Bytes 3-4     : height (uint16 LE)
#   Byte 5        : num_frames
#   Bytes 6-15    : reserved
#   Bytes 16+     : raw pixel data — 1 byte per pixel (palette index),
#                   width×height bytes per frame, colour 0 = transparent

def _load_rs8(path):
    """Load an rs8 file and return a list of pygame.Surface (one per frame)."""
    if path in _sprite_cache:
        return _sprite_cache[path]

    # Search order: current dir, then script dir
    search_dirs = [os.getcwd(), os.path.dirname(os.path.abspath(__file__))]
    full_path = None
    for d in search_dirs:
        candidate = os.path.join(d, path)
        if os.path.exists(candidate):
            full_path = candidate
            break

    if full_path is None:
        # Return a 16×16 magenta placeholder
        surf = pygame.Surface((16, 16))
        surf.fill((255, 0, 255))
        _sprite_cache[path] = [surf]
        return [surf]

    with open(full_path, "rb") as f:
        data = f.read()

    if len(data) < 16 or data[0:1] != b'R':
        surf = pygame.Surface((16, 16))
        surf.fill((255, 0, 255))
        _sprite_cache[path] = [surf]
        return [surf]

    # Actual layout (verified from binary inspection of game sprites):
    #   Byte 0  : 'R'
    #   Byte 1  : padding
    #   Byte 2  : width  (uint8)
    #   Byte 3  : padding
    #   Byte 4  : height (uint8)
    #   Byte 5  : num_frames (uint8)
    #   Bytes 6-15 : reserved
    #   Bytes 16+  : pixel data (1 byte per pixel, palette index, 0=transparent)
    w          = data[2]
    h          = data[4]
    num_frames = data[5]
    if num_frames == 0:
        num_frames = 1

    frame_size = w * h
    frames = []
    offset = 16
    for _ in range(num_frames):
        surf = pygame.Surface((w, h), pygame.SRCALPHA)
        surf.fill((0, 0, 0, 0))
        chunk = data[offset: offset + frame_size]
        for py in range(h):
            for px in range(w):
                byte_idx = py * w + px
                if byte_idx >= len(chunk):
                    break
                idx = chunk[byte_idx]
                if idx == 0:
                    continue   # transparent
                r, g, b = PALETTE[idx % 16]
                surf.set_at((px, py), (r, g, b, 255))
        frames.append(surf)
        offset += frame_size

    _sprite_cache[path] = frames
    return frames


# ---------------------------------------------------------------------------
# draw  module
# ---------------------------------------------------------------------------
class _Draw:
    def __init__(self):
        self.currColor = 7

    def _surf(self):
        return _surface

    def clear(self, color=0):
        self._surf().fill(_pal(color))

    def pixel(self, x, y, color=None):
        c = color if color is not None else self.currColor
        self._surf().set_at((int(x), int(y)), _pal(c))

    def filled_rect(self, x, y, w, h, color):
        pygame.draw.rect(self._surf(), _pal(color),
                         (int(x), int(y), int(w), int(h)))

    def rect(self, x, y, w, h, color):
        pygame.draw.rect(self._surf(), _pal(color),
                         (int(x), int(y), int(w), int(h)), 1)

    def line(self, x1, y1, x2, y2, color):
        pygame.draw.line(self._surf(), _pal(color),
                         (int(x1), int(y1)), (int(x2), int(y2)))

    def circle(self, x, y, r, color, filled=False):
        if filled:
            pygame.draw.circle(self._surf(), _pal(color),
                               (int(x), int(y)), int(r))
        else:
            pygame.draw.circle(self._surf(), _pal(color),
                               (int(x), int(y)), int(r), 1)

    def filled_circle(self, x, y, r, color):
        self.circle(x, y, r, color, filled=True)

    def text(self, txt, x, y, color=7):
        global _font
        if _font is None:
            return
        surf = _font.render(str(txt), False, _pal(color))
        self._surf().blit(surf, (int(x), int(y)))


draw = _Draw()


# ---------------------------------------------------------------------------
# kb  module  — keyboard input
# ---------------------------------------------------------------------------
class _KB:
    """
    Maps keys to retroPy button names.

    read_*()   → 0 if held, 1 if not (retroPy convention, active-low)
    *_down()   → True on the frame the key was first pressed
    *_up()     → True on the frame the key was released
    """
    def __init__(self):
        self._held    = set()   # keys currently held
        self._just_dn = set()   # keys pressed this frame
        self._just_up = set()   # keys released this frame

        # Key mapping: button name → list of pygame key constants
        self._map = {
            "left":   [pygame.K_LEFT],
            "right":  [pygame.K_RIGHT],
            "up":     [pygame.K_UP],
            "down":   [pygame.K_DOWN],
            "A":      [pygame.K_z, pygame.K_RETURN],
            "B":      [pygame.K_x, pygame.K_RSHIFT, pygame.K_LSHIFT],
            "Tleft":  [pygame.K_q, pygame.K_TAB],
            "Tright": [pygame.K_e],
        }

    def _pressed(self, name):
        return any(k in self._held for k in self._map[name])

    def _just_pressed(self, name):
        return any(k in self._just_dn for k in self._map[name])

    def _just_released(self, name):
        return any(k in self._just_up for k in self._map[name])

    # active-low reads (0 = pressed, 1 = not pressed)
    def read_left(self):   return 0 if self._pressed("left")  else 1
    def read_right(self):  return 0 if self._pressed("right") else 1
    def read_up(self):     return 0 if self._pressed("up")    else 1
    def read_down(self):   return 0 if self._pressed("down")  else 1
    def read_B(self):      return 0 if self._pressed("B")     else 1

    # edge-triggered downs
    def left_down(self):   return self._just_pressed("left")
    def right_down(self):  return self._just_pressed("right")
    def up_down(self):     return self._just_pressed("up")
    def down_down(self):   return self._just_pressed("down")
    def A_down(self):      return self._just_pressed("A")
    def B_down(self):      return self._just_pressed("B")
    def Tleft_down(self):  return self._just_pressed("Tleft")
    def Tright_down(self): return self._just_pressed("Tright")

    # edge-triggered ups
    def left_up(self):     return self._just_released("left")
    def right_up(self):    return self._just_released("right")
    def up_up(self):       return self._just_released("up")
    def down_up(self):     return self._just_released("down")
    def A_up(self):        return self._just_released("A")
    def B_up(self):        return self._just_released("B")

    def _tick(self, events):
        """Called once per frame by gameloop to refresh state."""
        self._just_dn.clear()
        self._just_up.clear()
        for ev in events:
            if ev.type == pygame.KEYDOWN:
                self._held.add(ev.key)
                self._just_dn.add(ev.key)
            elif ev.type == pygame.KEYUP:
                self._held.discard(ev.key)
                self._just_up.add(ev.key)


kb = _KB()


# ---------------------------------------------------------------------------
# dt()  — delta time helper (seconds since last frame)
# ---------------------------------------------------------------------------
def dt():
    return _dt


# ---------------------------------------------------------------------------
# gameObj  class
# ---------------------------------------------------------------------------
class gameObj:
    """
    Sprite-based game object.

    gameObj(sprite_path, x, y [, flip_duration [, speed_x, speed_y]])
      sprite_path    : .rs8 file path (relative to game folder)
      x, y           : initial position
      flip_duration  : ms per animation frame (0 = static / no auto-advance)
      speed_x/y      : pixels per second velocity (rarely used directly)
    """
    def __init__(self, sprite_path, x=0, y=0, flip_duration=0,
                 speed_x=0, speed_y=0):
        self._path          = sprite_path
        self.pos_x          = float(x)
        self.pos_y          = float(y)
        self.speed_x        = float(speed_x)
        self.speed_y        = float(speed_y)
        self._flip_duration = flip_duration
        self._flip_mode     = 0
        self._frame         = 0
        self._frame_timer   = 0.0
        self._frames_cache  = None   # lazy — loaded on first use after display init
        self._visible       = True

    def _get_frames(self):
        if self._frames_cache is None:
            self._frames_cache = _load_rs8(self._path)
        return self._frames_cache

    # --- properties ---
    @property
    def frame(self):
        return self._frame

    @frame.setter
    def frame(self, v):
        self._frame = int(v) % max(1, len(self._get_frames()))

    @property
    def visible(self):
        return self._visible

    @visible.setter
    def visible(self, v):
        self._visible = bool(v)

    def _num_frames(self):
        return len(self._get_frames())

    def flip(self, mode):
        self._flip_mode = int(mode)

    def sprite(self, new_path, new_flip_duration=0):
        if new_path != self._path:
            self._path        = new_path
            self._frames_cache = None   # invalidate so _get_frames reloads
            self._frame       = 0
            self._frame_timer = 0.0
        self._flip_duration = new_flip_duration

    def update(self, delta=None):
        if delta is None:
            delta = _dt
        self.pos_x += self.speed_x * delta
        self.pos_y += self.speed_y * delta
        frames = self._get_frames()
        if self._flip_duration > 0 and len(frames) > 1:
            self._frame_timer += delta * 1000
            while self._frame_timer >= self._flip_duration:
                self._frame_timer -= self._flip_duration
                self._frame = (self._frame + 1) % len(frames)

    def draw(self):
        if not self._visible:
            return
        surf = _surface
        if surf is None:
            return
        frames = self._get_frames()
        if not frames:
            return
        frame_idx = self._frame % len(frames)
        img = frames[frame_idx]
        fx = self._flip_mode in (1, 3)
        fy = self._flip_mode in (2, 3)
        if fx or fy:
            img = pygame.transform.flip(img, fx, fy)
        surf.blit(img, (int(self.pos_x), int(self.pos_y)))

    def drawCollider(self, color=7):
        frames = self._get_frames()
        if not frames:
            return
        draw.rect(int(self.pos_x), int(self.pos_y),
                  frames[0].get_width(), frames[0].get_height(), color)

    def colliderPt(self, x, y):
        frames = self._get_frames()
        if not frames:
            return False
        w = frames[0].get_width()
        h = frames[0].get_height()
        return (self.pos_x <= x < self.pos_x + w and
                self.pos_y <= y < self.pos_y + h)

    def deactivate(self):
        self._visible = False

    def active(self):
        return self._visible

    def clamp_x(self, min_x, max_x):
        self.pos_x = max(float(min_x), min(self.pos_x, float(max_x)))

    def clamp_y(self, min_y, max_y):
        self.pos_y = max(float(min_y), min(self.pos_y, float(max_y)))

    @property
    def width(self):
        frames = self._get_frames()
        return frames[0].get_width() if frames else 0

    @property
    def height(self):
        frames = self._get_frames()
        return frames[0].get_height() if frames else 0

    @property
    def mid_x(self):
        return self.pos_x + self.width / 2

    @property
    def mid_y(self):
        return self.pos_y + self.height / 2

    def currNdx(self, n):
        self._frame = int(n) % max(1, len(self._get_frames()))

    def collider(self, other):
        frames = self._get_frames()
        oframes = other._get_frames()
        if not frames or not oframes:
            return False
        aw = frames[0].get_width();  ah = frames[0].get_height()
        bw = oframes[0].get_width(); bh = oframes[0].get_height()
        return (self.pos_x < other.pos_x + bw and
                self.pos_x + aw > other.pos_x and
                self.pos_y < other.pos_y + bh and
                self.pos_y + ah > other.pos_y)


# ---------------------------------------------------------------------------
# disp stub  (main.py calls disp.init() with hardware params — ignored here)
# ---------------------------------------------------------------------------
class _Disp:
    TYPE_320 = 0
    def init(self, *args, **kwargs):
        pass   # no-op on PC

disp = _Disp()


# ---------------------------------------------------------------------------
# gameloop  class
# ---------------------------------------------------------------------------
class gameloop:
    """
    gameloop(Update, Draw)
    .run()   → starts the pygame event loop; never returns until window closed.
    """
    def __init__(self, update_fn, draw_fn):
        self._update = update_fn
        self._draw   = draw_fn

    def _init_pygame(self):
        global _surface, _display, _clock, _font

        pygame.init()
        pygame.display.set_caption("Chaos Unraveled  —  PC Port")

        existing = pygame.display.get_surface()
        if existing is not None:
            _display = existing
        else:
            _display = pygame.display.set_mode((SCREEN_W * SCALE, SCREEN_H * SCALE))
        _surface = pygame.Surface((SCREEN_W, SCREEN_H))
        _clock   = pygame.time.Clock()

        try:
            _font = pygame.font.Font(None, 16)
        except Exception:
            _font = None

    def _tick_frame(self, prev):
        global _dt
        now  = time.perf_counter()
        _dt  = min(now - prev, 0.05)

        events = pygame.event.get()
        for ev in events:
            if ev.type == pygame.QUIT:
                return False, now
            if ev.type == pygame.KEYDOWN and ev.key == pygame.K_ESCAPE:
                return False, now

        kb._tick(events)

        try:
            self._update()
        except Exception as e:
            print(f"[Update error] {e}")

        _surface.fill((0, 0, 0))
        try:
            self._draw()
        except Exception as e:
            print(f"[Draw error] {e}")

        dw = _display.get_width()
        dh = _display.get_height()
        scaled = pygame.transform.scale(_surface, (dw, dh))
        _display.blit(scaled, (0, 0))
        pygame.display.flip()
        _clock.tick(_fps)
        return True, now

    def run(self):
        """Blocking loop — used for native desktop."""
        self._init_pygame()
        prev    = time.perf_counter()
        running = True
        while running:
            running, prev = self._tick_frame(prev)
        pygame.quit()

    async def run_async(self):
        """Async loop — required by pygbag for WebAssembly/GitHub Pages."""
        try:
            self._init_pygame()
        except Exception as e:
            print(f"[INIT FAILED] {e}")
            import traceback; traceback.print_exc()
            return

        prev    = time.perf_counter()
        running = True
        while running:
            running, prev = self._tick_frame(prev)
            await asyncio.sleep(0)
        pygame.quit()


# ---------------------------------------------------------------------------
# Convenience: expose dt as both function and value
# ---------------------------------------------------------------------------
__all__ = [
    "draw", "kb", "dt", "gameObj", "gameloop", "disp",
    "PALETTE", "SCREEN_W", "SCREEN_H",
]

