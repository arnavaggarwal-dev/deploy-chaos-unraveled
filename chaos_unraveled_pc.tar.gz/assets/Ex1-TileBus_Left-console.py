import time, random, os
from retroPy import *
import gc
disp.init(
    machine.SPI(0, 32000000, sck=18, mosi=19, polarity=0, phase=0),
    screen=disp.TYPE_320,
    board=1,
)
#Sprites---------------------------------------------------------------------
mappy = gameObj("trash 1.rs8", 20, 32)
# ---------------------------------------------------------------------------
# TileBus
# ---------------------------------------------------------------------------
import tilebus_c as tbc
rxData = 0
def on_tilebus_data(src, dst, flags, payload):
    global rxData
    rxData = payload
    print("on_data", src, dst, flags, payload)
tb = tbc.TileBus(
    baud=277_777,
    left_uart=1,
    right_uart=0,
    left_tx=8,
    left_rx=9,
    right_tx=12,
    right_rx=13,
    is_master=False,
    my_id=-1,
)
# init TileBus
#tb = tbc.TileBus(baud=277_777, left_uart=1, right_uart=0, left_tx=8, left_rx=9, right_tx=12, right_rx=13, is_master=False, my_id=-1)
#tb = tbc.TileBus(baud=277_777, left_uart=1, right_uart=0, left_tx=4, left_rx=5, right_tx=0, right_rx=1, is_master=False, my_id=-1)
tb = tbc.TileBus(baud=277_777, left_uart=1, right_uart=1, left_tx=0, left_rx=1, right_tx=4, right_rx=5, is_master=False, my_id=-1)
tb.set_on_data(on_tilebus_data)
tb.restart()
# ---------------------------------------------------------------------------
print("Left start")
cc = 0
def Update():
    global cc
    
    tb.poll()
    if kb.left_down():
        #print("pressed")
        tb.send_right(0xff, bytearray([65,66]), 0x0) 
    if kb.right_down():
        tb.send_right(0xff, bytearray([67,68]), 0x0)
        #print("pressed")
    elif kb.up_down():
        #print("pressed")  
        tb.send_right(0xff, bytearray([70,76]), 0x0) 
    if kb.down_down():
        tb.send_right(0xff, bytearray([82,82]), 0x0)
        #print("pressed")
    if kb.Tright_down():
        tb.send_right(0xff, bytearray([21,12]), 0x0)
        print("pressed")
    if kb.Tleft_down():
        print("pressed")
    if kb.A_down():
        tb.send_right(0xff, bytearray([22,82]), 0x0)
        print("pressed")
    if kb.B_down():
        tb.send_right(0xff, bytearray([82,82]), 0x0)
        #print("pressed")
    gc.collect()
# ---------------------------------------------------------------------------
def Draw():
    gc.collect()
    global cc
    draw.clear()
    mappy.draw()
    draw.text("rx " + str(rxData), 2, 2, 7)
# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
gloop = gameloop(Update, Draw)
gloop.run()
print("Done.")

