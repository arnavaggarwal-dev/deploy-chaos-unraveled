import math
from retroPy import *
import game_state

# =========================================================
# PLAYER PROFILES
# =========================================================
PROFILES = [
    {"name": "CLANKER",  "sprite": "sideclanker.rs8",              "speed": 90, "w": 12, "h": 12},
    {"name": "HW FRONT", "sprite": "High_water_clanker.rs8",       "speed": 70, "w": 14, "h": 14},
    {"name": "HW BACK",  "sprite": "High_water_clanker - BACK.rs8","speed": 70, "w": 14, "h": 14},
]

profile_objs = []
for p in PROFILES:
    try:
        profile_objs.append(gameObj(p["sprite"], -200, -200))
    except:
        profile_objs.append(gameObj("sideclanker.rs8", -200, -200))


# =========================================================
# MAP
# 0=floor  1=wall  2=decoration
# Top-right cave (cols 27-29, rows 0-2) = boss trigger zone
# =========================================================
TILE  = 16
MAP_W = 30
MAP_H = 20

COLOR_FLOOR     = 1
COLOR_WALL      = 7
COLOR_DECO      = 3
COLOR_TRIG      = 2
LIGHT_BLUE_TILE = 12

# =========================================================
# SAFE — 4x4 tiles at cols 19-22, rows 8-11
# Locked (solid) until all 9 keys collected
# =========================================================
SAFE_COL   = 19
SAFE_ROW   = 8
SAFE_W     = 4   # tiles wide
SAFE_H     = 4   # tiles tall
safe_open  = False   # flips True when keys_collected == 9

try:
    cutscene_obj = gameObj("smoothclanker.rs8", -300, -300)
except:
    cutscene_obj = gameObj("sideclanker.rs8", -300, -300)
cutscene_t   = 0     # frame counter for cutscene animation

# fmt: off
MAP = bytearray([
    1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,
    1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,
    1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,
    1,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,1,
    1,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,
    1,0,0,1,0,0,0,0,0,2,2,2,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,1,
    1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
    1,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,1,
    1,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,
    1,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,1,
    1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
    1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
    1,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,0,0,1,
    1,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,1,
    1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
    1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
    1,0,0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,1,0,0,0,1,
    1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
    1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,
    1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
])
# fmt: on

# Boss trigger zone: top-right cave
TRIGGER_COL_MIN = 27
TRIGGER_ROW_MAX = 2

# =========================================================
# MAP HELPERS
# =========================================================
def xy(col, row):        return row * MAP_W + col
def set_tile(col, row, v):
    if 0 <= col < MAP_W and 0 <= row < MAP_H:
        MAP[xy(col, row)] = v
def get_tile(col, row):
    if 0 <= col < MAP_W and 0 <= row < MAP_H:
        return MAP[xy(col, row)]
    return 1
def is_wall(col, row):   return get_tile(col, row) == 1

# stamp safe as solid wall tiles initially
for _sr in range(SAFE_ROW, SAFE_ROW + SAFE_H):
    for _sc in range(SAFE_COL, SAFE_COL + SAFE_W):
        set_tile(_sc, _sr, 1)

# ---- bottom-left cave for boss 3 ----
for _r in range(14, 19):
    set_tile(0, _r, 0)

BOSS3_TRIGGER_COL_MAX = 0
BOSS3_TRIGGER_ROW_MIN = 14

# pantheon cave — centre of map, cols 13-15 rows 7-11
PANTHEON_COL_MIN = 13
PANTHEON_COL_MAX = 15
PANTHEON_ROW_MIN = 7
PANTHEON_ROW_MAX = 11

# boss4 cave: bottom-right corner cols 27-29, rows 17-19

# ---- pantheon cave — sealed until all bosses beaten ----
for _r in range(PANTHEON_ROW_MIN, PANTHEON_ROW_MAX + 1):
    for _c in range(PANTHEON_COL_MIN, PANTHEON_COL_MAX + 1):
        set_tile(_c, _r, 1)

# 6 collectible key tiles (tile value 2) — 5 in map data + 1 added here
set_tile(15, 10, 2)

# animation counter for sparkle draw effect
sparkle_frame  = 0
pantheon_pulse = 0   # pulse counter for gate VFX

# =========================================================
# PLAYER STATE
# =========================================================
SCREEN_W = 320
SCREEN_H = 240

player_x    = 32.0
player_y    = 32.0
player_obj  = None
player_w    = 12
player_h    = 12
player_spd  = 140
player_dir  = 1
facing_down = False
facing_up   = False
cam_x       = 0
cam_y       = 0

# character select state
selected  = 0
in_select = True

# result display timer (frames to show win/lose before clearing)
result_timer    = 0
RESULT_SHOW     = 180   # 180 frames ≈ 5.5s

# =========================================================
# INIT
# =========================================================
def _apply_debug_vault():
    """Force-opens the safe immediately if DEBUG_UNLOCK_VAULT is True."""
    global safe_open
    if game_state.DEBUG_UNLOCK_VAULT and not safe_open:
        safe_open = True
        for _sr in range(SAFE_ROW, SAFE_ROW + SAFE_H):
            for _sc in range(SAFE_COL, SAFE_COL + SAFE_W):
                set_tile(_sc, _sr, 0)
    # reopen pantheon tiles whenever we return to map if already unlocked
    if game_state.pantheon_unlocked:
        for _r in range(PANTHEON_ROW_MIN, PANTHEON_ROW_MAX + 1):
            for _c in range(PANTHEON_COL_MIN, PANTHEON_COL_MAX + 1):
                set_tile(_c, _r, 0)

def init():
    """Called by main.py when entering MAP scene."""
    global player_x, player_y, player_obj, player_w, player_h
    global player_spd, player_dir, facing_down, facing_up
    global in_select, selected, result_timer

    # kill any music from boss fights
    try:
        import retrobeep
        retrobeep.reset_all()
    except:
        pass

    selected    = game_state.selected_profile
    in_select   = False

    player_x   = game_state.spawn_x
    player_y   = game_state.spawn_y
    player_dir = 1
    facing_down = False
    facing_up   = False

    p           = PROFILES[selected]
    player_obj  = profile_objs[selected]
    player_w    = p["w"]
    player_h    = p["h"]
    player_spd  = p["speed"]
    player_obj.flip(1)

    result_timer = RESULT_SHOW if game_state.result is not None else 0

    _apply_debug_vault()

def init_select():
    """Called by main.py on very first launch."""
    global in_select, selected
    in_select = True
    selected  = 0
    _apply_debug_vault()

# =========================================================
# MOVEMENT
# =========================================================
def move_player(dx, dy):
    global player_x, player_y

    new_x = player_x + dx
    cl = int(new_x) // TILE;  cr = int(new_x + player_w - 1) // TILE
    rt = int(player_y) // TILE; rb = int(player_y + player_h - 1) // TILE
    if not (is_wall(cl,rt) or is_wall(cl,rb) or is_wall(cr,rt) or is_wall(cr,rb)):
        player_x = new_x

    new_y = player_y + dy
    cl = int(player_x) // TILE;  cr = int(player_x + player_w - 1) // TILE
    rt = int(new_y) // TILE; rb = int(new_y + player_h - 1) // TILE
    if not (is_wall(cl,rt) or is_wall(cl,rb) or is_wall(cr,rt) or is_wall(cr,rb)):
        player_y = new_y

    player_x = max(0, min(player_x, MAP_W * TILE - player_w))
    player_y = max(0, min(player_y, MAP_H * TILE - player_h))

def update_camera():
    global cam_x, cam_y
    cam_x = max(0, min(int(player_x) - SCREEN_W//2, MAP_W*TILE - SCREEN_W))
    cam_y = max(0, min(int(player_y) - SCREEN_H//2, MAP_H*TILE - SCREEN_H))

# =========================================================
# UPDATE  — returns "BOSS" if trigger hit, else None
# =========================================================
def update():
    global in_select, selected, player_dir, facing_down, facing_up
    global player_obj, result_timer

    # ---- character select ----
    if in_select:
        if kb.left_down():
            selected = (selected - 1) % len(PROFILES)
        if kb.right_down():
            selected = (selected + 1) % len(PROFILES)
        if kb.A_down():
            in_select = False
            game_state.selected_profile = selected
            p = PROFILES[selected]
            global player_w, player_h, player_spd, player_x, player_y
            player_w   = p["w"];  player_h  = p["h"]
            player_spd = p["speed"]
            player_x   = float(TILE * 2);  player_y = float(TILE * 2)
            game_state.spawn_x = player_x;  game_state.spawn_y = player_y
            player_obj = profile_objs[selected]
            player_obj.flip(1)
        return None

    # ---- result countdown ----
    if result_timer > 0:
        result_timer -= 1
        if result_timer == 0:
            game_state.result = None   # clear after shown

    # ---- movement ----
    speed = player_spd * dt()
    dx = 0.0;  dy = 0.0

    if kb.read_left()  == 0:
        dx = -speed
        if player_dir != -1:
            player_dir = -1;  player_obj.flip(0)
    if kb.read_right() == 0:
        dx = speed
        if player_dir != 1:
            player_dir = 1;  player_obj.flip(1)
    if kb.read_up()    == 0:  dy = -speed
    if kb.read_down()  == 0:  dy =  speed

    # sprite swap on vertical direction
    now_down = kb.read_down() == 0
    now_up   = kb.read_up()   == 0
    if now_down != facing_down or now_up != facing_up:
        facing_down = now_down;  facing_up = now_up
        if facing_down:       player_obj = profile_objs[1]
        elif facing_up:       player_obj = profile_objs[2]
        else:                 player_obj = profile_objs[selected]
        player_obj.flip(1 if player_dir == 1 else 0)

    if dx != 0 and dy != 0:
        dx *= 0.707;  dy *= 0.707

    move_player(dx, dy)
    update_camera()

    # ---- key tile pickup ----
    # check all four corners of player hitbox so pickup feels generous
    col = int(player_x) // TILE
    row = int(player_y) // TILE
    for tc, tr in [(col, row), (col+1, row), (col, row+1), (col+1, row+1)]:
        if get_tile(tc, tr) == 2:
            set_tile(tc, tr, 0)        # remove tile from map
            game_state.keys_collected = min(9, game_state.keys_collected + 1)
            break

    global safe_open, pantheon_pulse
    pantheon_pulse += 1

    # ---- safe: unlock when all keys collected (or debug override) ----
    if (game_state.keys_collected >= 9 or game_state.DEBUG_UNLOCK_VAULT) and not safe_open:
        safe_open = True
        # clear safe tiles so player can walk in
        for _sr in range(SAFE_ROW, SAFE_ROW + SAFE_H):
            for _sc in range(SAFE_COL, SAFE_COL + SAFE_W):
                set_tile(_sc, _sr, 0)

    # ---- safe entry triggers cutscene ----
    col = int(player_x) // TILE
    row = int(player_y) // TILE
    if safe_open:
        if (SAFE_COL <= col < SAFE_COL + SAFE_W and
                SAFE_ROW <= row < SAFE_ROW + SAFE_H):
            return "CUTSCENE"

    # ---- pantheon: unlock when all 4 bosses beaten ----
    if (game_state.boss1_key_given and game_state.boss2_key_given and
            game_state.boss3_key_given and getattr(game_state, 'boss4_key_given', False)):
        if not game_state.pantheon_unlocked:
            game_state.pantheon_unlocked = True
            # open the cave tiles
            for _r in range(PANTHEON_ROW_MIN, PANTHEON_ROW_MAX + 1):
                for _c in range(PANTHEON_COL_MIN, PANTHEON_COL_MAX + 1):
                    set_tile(_c, _r, 0)

    # ---- pantheon trigger → goes to MAP2 first ----
    if game_state.pantheon_unlocked:
        if (PANTHEON_COL_MIN <= col <= PANTHEON_COL_MAX and
                PANTHEON_ROW_MIN <= row <= PANTHEON_ROW_MAX):
            game_state.spawn_x = float(PANTHEON_COL_MIN * TILE)
            game_state.spawn_y = float((PANTHEON_ROW_MIN - 1) * TILE)
            return "MAP2"

    # ---- boss trigger ----
    col = int(player_x) // TILE
    row = int(player_y) // TILE
    if col >= TRIGGER_COL_MIN and row <= TRIGGER_ROW_MAX:
        # save spawn point just outside the cave entrance
        game_state.spawn_x = float((TRIGGER_COL_MIN - 1) * TILE)
        game_state.spawn_y = float(TILE * 2)
        return "BOSS"

    # ---- boss3 trigger (bottom-left cave) ----
    if col <= BOSS3_TRIGGER_COL_MAX and row >= BOSS3_TRIGGER_ROW_MIN:
        game_state.spawn_x = float(TILE * 2)
        game_state.spawn_y = float((BOSS3_TRIGGER_ROW_MIN - 1) * TILE)
        return "BOSS3"

    return None

# =========================================================
# DRAW
# =========================================================
def draw_select():
    draw.clear(0)
    draw.text("SELECT PROFILE", 90, 20, 15)
    draw.text("LEFT/RIGHT  A=confirm", 60, 30, 7)
    for i, p in enumerate(PROFILES):
        obj = profile_objs[i]
        sx  = 60 + i * 80;  sy = 90
        obj.pos_x = sx;  obj.pos_y = sy;  obj.draw()
        draw.rect(sx-4, sy-4, 24, 24, 15 if i==selected else 5)
        draw.text(p["name"],       sx-8, sy+22, 15 if i==selected else 5)
        draw.text("SPD:"+str(p["speed"]), sx-6, sy+30, 7)
    for obj in profile_objs:
        obj.pos_x = -200;  obj.pos_y = -200

def draw_map_tiles():
    sc = cam_x // TILE;  sr = cam_y // TILE
    ec = min(MAP_W, sc + SCREEN_W//TILE + 2)
    er = min(MAP_H, sr + SCREEN_H//TILE + 2)
    for row in range(sr, er):
        for col in range(sc, ec):
            tile = get_tile(col, row)
            sx = col*TILE - cam_x;  sy = row*TILE - cam_y
            if tile == 0:
                # highlight boss1 trigger zone
                if col >= TRIGGER_COL_MIN and row <= TRIGGER_ROW_MAX:
                    draw.filled_rect(sx, sy, TILE, TILE, COLOR_TRIG)
                # highlight boss3 trigger zone (bottom-left cave)
                elif col <= BOSS3_TRIGGER_COL_MAX and row >= BOSS3_TRIGGER_ROW_MIN:
                    draw.filled_rect(sx, sy, TILE, TILE, LIGHT_BLUE_TILE)
                else:
                    draw.filled_rect(sx, sy, TILE, TILE, COLOR_FLOOR)
            elif tile == 1:
                draw.filled_rect(sx, sy, TILE, TILE, COLOR_WALL)
                draw.rect(sx+1, sy+1, TILE-2, TILE-2,
                          COLOR_WALL-1 if COLOR_WALL>1 else COLOR_WALL)
            elif tile == 2:
                draw.filled_rect(sx, sy, TILE, TILE, COLOR_FLOOR)
                # sparkle — 4-point star that rotates phase each frame
                cx = sx + TILE // 2
                cy = sy + TILE // 2
                phase = (sparkle_frame + col * 3 + row * 7) % 16
                # outer arms (long axis rotates)
                if phase < 8:
                    draw.line(cx, cy-5, cx, cy+5, 15)
                    draw.line(cx-5, cy, cx+5, cy, 9)
                else:
                    draw.line(cx-4, cy-4, cx+4, cy+4, 15)
                    draw.line(cx-4, cy+4, cx+4, cy-4, 9)
                # bright centre dot
                draw.filled_rect(cx-1, cy-1, 3, 3, 15)

    # pantheon cave overlay — only visible when unlocked
    if game_state.pantheon_unlocked:
        pcx = PANTHEON_COL_MIN * TILE - cam_x
        pcy = PANTHEON_ROW_MIN * TILE - cam_y
        pcw = (PANTHEON_COL_MAX - PANTHEON_COL_MIN + 1) * TILE
        pch = (PANTHEON_ROW_MAX - PANTHEON_ROW_MIN + 1) * TILE
        # thickness pulses 1→4→1 using sine
        thickness = 1 + int(math.sin(pantheon_pulse * 0.08) * 1.5 + 1.5)
        for t in range(thickness):
            draw.rect(pcx - t, pcy - t, pcw + t*2, pch + t*2, 9)
        draw.rect(pcx+2, pcy+2, pcw-4, pch-4, 14)
        draw.line(pcx + pcw//2, pcy+2,      pcx + pcw//2, pcy+pch-2, 15)
        draw.line(pcx+2,        pcy+pch//2, pcx+pcw-2,    pcy+pch//2, 15)
        draw.text("[]", pcx + pcw//2 - 4, pcy + pch//2 - 4, 15)
    sx0 = SAFE_COL * TILE - cam_x
    sy0 = SAFE_ROW * TILE - cam_y
    sw  = SAFE_W * TILE
    sh  = SAFE_H * TILE
    if safe_open:
        draw.filled_rect(sx0, sy0, sw, sh, COLOR_FLOOR)
        draw.rect(sx0,   sy0,   sw,   sh,   10)
        draw.rect(sx0+2, sy0+2, sw-4, sh-4, 10)
        draw.text("OPEN", sx0 + 14, sy0 + 26, 10)
    else:
        draw.filled_rect(sx0, sy0, sw, sh, 5)
        draw.rect(sx0,   sy0,   sw,   sh,   7)
        draw.rect(sx0+3, sy0+3, sw-6, sh-6, 7)
        # dial
        vcx = sx0 + sw // 2
        vcy = sy0 + sh // 2
        draw.circle(vcx, vcy, 10, 7)
        draw.circle(vcx, vcy,  6, 5)
        draw.filled_rect(vcx-1, vcy-10, 3, 5, 7)
        draw.text("LOCKED", sx0 + 6, sy0 + sh - 12, 2)
        draw.text(str(game_state.keys_collected)+"/9", sx0 + 20, sy0 - 10, 14)

def draw_scene():
    global sparkle_frame, pantheon_pulse, in_select, player_x, player_y, player_obj, cam_x, cam_y, selected, result_timer, safe_open
    sparkle_frame += 1
    draw.clear(0)

    if in_select:
        draw_select()
        return

    draw_map_tiles()

    if player_obj is None:
        return

    sx = int(player_x) - cam_x
    sy = int(player_y) - cam_y
    player_obj.pos_x = sx;  player_obj.pos_y = sy
    player_obj.draw()

    # HUD
    col = int(player_x) // TILE
    row = int(player_y) // TILE
    draw.text(PROFILES[selected]["name"], 4, 4, 15)
    draw.text("tile:"+str(col)+","+str(row), 4, 12, 7)
    draw.text("WEP:"+game_state.WEAPON_TYPE, 4, 20, 9)
    draw.text("KEYS:"+str(game_state.keys_collected)+"/9", 4, 28, 14)

    # cave hint arrow when near trigger
    if col >= TRIGGER_COL_MIN - 3 and row <= 5:
        draw.text(">>> BOSS CAVE", 180, 4, 9)

    if col <= 5 and row >= BOSS3_TRIGGER_ROW_MIN - 3:
        draw.text("ICE CAVE >>>", 4, 48, 12)

    if (abs(col - (PANTHEON_COL_MIN + 1)) < 4 and
            abs(row - (PANTHEON_ROW_MIN + 2)) < 4):
        if game_state.pantheon_unlocked:
            draw.text("PANTHEON", 120, 220, 9)

    # result message
    if result_timer > 0 and game_state.result is not None:
        if game_state.result == "WIN":
            draw.text("BOSS DEFEATED!", 100, 110, 10)
            draw.text("You escaped the cave.", 80, 120, 15)
        else:
            draw.text("YOU DIED.", 120, 110, 2)
            draw.text("Back to safety...", 90, 120, 15)

# =========================================================
# CUTSCENE
# smoothclanker.rs8 swaying on a sinewave, press A to skip
# =========================================================
CUTSCENE_LEN = 300   # frames before auto-return to map

def update_cutscene():
    global cutscene_t
    cutscene_t += 1
    cutscene_obj.pos_x = int(120 + math.sin(cutscene_t * 0.06) * 80)
    cutscene_obj.pos_y = 90
    cutscene_obj.update()
    if cutscene_t > CUTSCENE_LEN or kb.A_down():
        cutscene_t = 0
        cutscene_obj.pos_x = -300
        cutscene_obj.pos_y = -300
        return True   # done
    return False

def draw_cutscene():
    draw.clear(0)
    draw.filled_rect(20, 20, 280, 200, 1)
    draw.rect(20, 20, 280, 200, 7)
    draw.text("THE VAULT OPENS...", 72, 30, 15)
    cutscene_obj.draw()
    draw.text("Something stirs", 75, 150, 7)
    draw.text("deep within the dark...", 55, 162, 7)
    draw.text("[ A ] to skip", 108, 192, 5)