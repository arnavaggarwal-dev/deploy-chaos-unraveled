"""Serve build/web without rebuilding (preserves HTML patches)."""
import http.server, socketserver, os
from pathlib import Path

PORT = 8000
WEB  = Path(__file__).parent / "build" / "web"

class Handler(http.server.SimpleHTTPRequestHandler):
    def __init__(self, *a, **kw):
        super().__init__(*a, directory=str(WEB), **kw)

    def guess_type(self, path):
        if str(path).endswith(".wasm"):
            return "application/wasm"
        return super().guess_type(path)

    def log_message(self, fmt, *args):
        pass  # silence per-request noise

print(f"Serving http://localhost:{PORT}  (Ctrl+C to stop)")
with socketserver.TCPServer(("", PORT), Handler) as s:
    s.serve_forever()
