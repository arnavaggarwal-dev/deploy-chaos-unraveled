==============================
  CHAOS UNRAVELED  — PC Port
==============================

Original retroPy game ported to run on Windows / Mac / Linux
using Python + pygame.

REQUIREMENTS
------------
  Python 3.9+
  pygame 2.6+  (auto-installed by the launcher)

HOW TO RUN
----------
  Windows:  Double-click  run_game.bat
  Mac/Linux: ./run_game.sh
  Any OS:   python main.py   (from this folder)

CONTROLS
--------
  Arrow Keys    Move
  Z             A button  (confirm on menus, fire/attack in boss fights)
  X             B button  (hold Up+X to enter Boss 2 from the map)
  Q             Left shoulder  (exit MAP2 back to main map)
  ESC           Quit

TIPS
----
  • Select your character with Left/Right arrows, confirm with Z
  • Collect glowing KEY tiles scattered around the map
  • Boss caves:  top-right (orange tiles)  &  bottom-left (blue tiles)
  • Press Up+X on the main map to fight Boss 2
  • Open the inventory with Up+X+Z held together
  • Change weapons in the inventory with Left/Right, confirm with Z

WINDOW SIZE
-----------
  The game renders internally at 320×240 (retroPy original resolution)
  and is scaled up 3× to 960×720.

