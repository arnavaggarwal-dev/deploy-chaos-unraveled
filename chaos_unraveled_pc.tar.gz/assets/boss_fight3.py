import random, math
from retroPy import *
import weapons
import game_state

# =========================================================
# BOSS 3 — boss3.rs8
#
# 4 totems at arena corners, each with 10 HP
# Totems ARE the boss health — kill all to win
#
# Phase 0 (4 totems alive):        frame 0,  wandering only
# Phase 1 (2 totems killed):       frame 2,  ray star bursts
# Phase 2 (3 totems killed):       frame 3,  ray star + radiation + ice spikes
# WIN     (all 4 totems killed)
#
# All attack VFX drawn manually in light blue (color 12)
# =========================================================

SCREEN_W   = 320
SCREEN_H   = 240
LIGHT_BLUE = 12

# =========================================================
# WEAPONS
# =========================================================
WEAPON_TYPE = "GUN"

gun     = weapons.Gun()
sword   = weapons.Sword()
trident = weapons.Trident()
pickaxe   = weapons.Pickaxe()
pimpillo  = weapons.Pimpillo()
wep_sprite = None

# =========================================================
# SPRITES
# =========================================================
boss_obj   = None
player_obj = None

def _make_sprites():
    global boss_obj, player_obj, wep_sprite
    boss_obj   = gameObj("boss3.rs8", 150, 60)
    player_obj = gameObj("sideclanker.rs8", 20, 180)
    player_obj.flip(1)
    wep_sprite = gameObj(
        "gun.rs8"     if WEAPON_TYPE == "GUN"     else
        "sword.rs8"   if WEAPON_TYPE == "SWORD"   else
        "trident.rs8" if WEAPON_TYPE == "TRIDENT" else
        "pickaxe.rs8"  if WEAPON_TYPE == "PICKAXE" else
        "pimpillo.rs8",
        -100, -100
    )

# =========================================================
# PLAYER HEALTH
# =========================================================
PLAYER_MAX_HP = 5
player_hp     = 5
INV_TIME      = 40
inv_timer     = 0

def try_hit_player(dmg):
    global player_hp, inv_timer
    if inv_timer == 0:
        player_hp = max(0, player_hp - dmg)
        inv_timer = INV_TIME

# =========================================================
# PHASE
# =========================================================
phase         = 0
totems_killed = 0

# =========================================================
# TOTEMS
# Fixed at four arena corners, 10 HP each
# =========================================================
TOTEM_MAX_HP  = 10
TOTEM_HIT_CD  = 10
CORNER_POSITIONS = [(20, 20), (280, 20), (20, 190), (280, 190)]

class Totem:
    def __init__(self, x, y):
        self.obj    = gameObj("totem.rs8", x, y)
        self.hp     = TOTEM_MAX_HP
        self.alive  = True
        self.hit_cd = 0
        # flash timer for hit feedback
        self.flash  = 0

    def try_hit(self, dmg):
        if self.hit_cd == 0 and self.alive:
            self.hp    -= dmg
            self.hit_cd = TOTEM_HIT_CD
            self.flash  = 8
            if self.hp <= 0:
                self.hp        = 0
                self.alive     = False
                self.obj.pos_x = -400
                self.obj.pos_y = -400
                return True   # killed
        return False

    def update(self):
        if self.hit_cd > 0: self.hit_cd -= 1
        if self.flash  > 0: self.flash  -= 1

    def draw(self):
        if not self.alive:
            return
        self.obj.draw()
        # HP bar above totem
        ox = int(self.obj.pos_x)
        oy = int(self.obj.pos_y)
        draw.filled_rect(ox, oy - 7, TOTEM_MAX_HP * 2, 3, 5)
        draw.filled_rect(ox, oy - 7, self.hp * 2,      3, LIGHT_BLUE)
        # hit flash
        if self.flash > 0 and self.flash % 2 == 0:
            draw.rect(ox - 2, oy - 2, self.obj.width + 4, self.obj.height + 4, 15)

totems = []

# =========================================================
# BOSS WANDER
# =========================================================
BOSS_SPD      = 30
boss_target_x = 150.0
boss_target_y = 70.0
wander_timer  = 0
WANDER_CD     = 100

# =========================================================
# ATK1 — RAY STAR  (phase 1+)
# Two bursts of 8 rays, second rotated by half a step
# =========================================================
rays         = []
RAY_BURST_CD  = 150
RAY_COUNT     = 8
RAY_SPD       = 5
RAY_MAX_LEN   = 220
RAY_BURST_GAP = 22

ray_timer       = 0
ray_burst_state = 0
ray_burst_timer = 0

class Ray:
    def __init__(self, ox, oy, angle):
        self.ox     = ox
        self.oy     = oy
        self.angle  = angle
        self.length = 0
        self.alive  = True

    def update(self):
        self.length += RAY_SPD
        if self.length >= RAY_MAX_LEN:
            self.alive = False

    def draw(self):
        ex = int(self.ox + math.cos(self.angle) * self.length)
        ey = int(self.oy + math.sin(self.angle) * self.length)
        draw.line(self.ox, self.oy, ex, ey, LIGHT_BLUE)

    def hits_point(self, px, py, margin=7):
        dx = math.cos(self.angle);  dy = math.sin(self.angle)
        t  = (px - self.ox)*dx + (py - self.oy)*dy
        if t < 0 or t > self.length:
            return False
        cx = self.ox + t*dx;  cy = self.oy + t*dy
        return math.sqrt((px-cx)**2 + (py-cy)**2) < margin

def fire_ray_burst(bx, by, offset=0.0):
    step = (2 * math.pi) / RAY_COUNT
    for i in range(RAY_COUNT):
        rays.append(Ray(bx, by, offset + step * i))

# =========================================================
# ATK2 — RADIATION WAVE  (phase 2)
# Expanding ring with gaps, fired twice per sequence
# =========================================================
rad_waves      = []
RAD_WAVE_CD      = 210
RAD_WAVE_SPD     = 3
RAD_WAVE_SPACING = 45
RAD_GAPS = [(15, 55), (105, 140), (195, 230), (285, 325)]

rad_timer      = 0
rad_wave_count = 0
rad_wave_gap   = 0

class RadWave:
    def __init__(self, ox, oy):
        self.ox     = ox
        self.oy     = oy
        self.radius = 8
        self.alive  = True

    def _in_gap(self, deg):
        deg = deg % 360
        for s, e in RAD_GAPS:
            if s <= deg <= e:
                return True
        return False

    def update(self):
        self.radius += RAD_WAVE_SPD
        if self.radius > 260:
            self.alive = False

    def draw(self):
        for deg in range(0, 360, 4):
            if self._in_gap(deg):
                continue
            a  = math.radians(deg)
            px = int(self.ox + math.cos(a) * self.radius)
            py = int(self.oy + math.sin(a) * self.radius)
            draw.filled_rect(px - 1, py - 1, 3, 3, LIGHT_BLUE)

    def hits_point(self, px, py, margin=10):
        dist = math.sqrt((px - self.ox)**2 + (py - self.oy)**2)
        if abs(dist - self.radius) > margin:
            return False
        deg = math.degrees(math.atan2(py - self.oy, px - self.ox)) % 360
        return not self._in_gap(deg)

# =========================================================
# ATK3 — ICE SPIKES  (phase 2)
# Lines growing from screen edges over 40 frames
# =========================================================
ice_spikes     = []
ICE_SPIKE_CD   = 260
ICE_SPIKE_GROW = 40
ICE_SPIKE_HOLD = 40

ice_timer = 0

class IceSpike:
    def __init__(self):
        edge = random.randint(0, 3)
        if edge == 0:
            self.x1, self.y1 = random.randint(10, SCREEN_W-10), 0
            base_a = math.pi / 2
        elif edge == 1:
            self.x1, self.y1 = random.randint(10, SCREEN_W-10), SCREEN_H
            base_a = -math.pi / 2
        elif edge == 2:
            self.x1, self.y1 = 0, random.randint(10, SCREEN_H-10)
            base_a = 0.0
        else:
            self.x1, self.y1 = SCREEN_W, random.randint(10, SCREEN_H-10)
            base_a = math.pi

        self.angle   = base_a + random.uniform(-0.25, 0.25)
        self.max_len = random.randint(60, 130)
        self.growth  = 0
        self.hold    = 0
        self.alive   = True

    def _cur_len(self):
        return int(self.max_len * min(1.0, self.growth / ICE_SPIKE_GROW))

    def update(self):
        if self.growth < ICE_SPIKE_GROW:
            self.growth += 1
        else:
            self.hold += 1
            if self.hold >= ICE_SPIKE_HOLD:
                self.alive = False

    def draw(self):
        l = self._cur_len()
        if l < 2:
            return
        ex = int(self.x1 + math.cos(self.angle) * l)
        ey = int(self.y1 + math.sin(self.angle) * l)
        draw.line(self.x1, self.y1, ex, ey, LIGHT_BLUE)
        if l > 12:
            tip = l // 5
            for off in (-0.4, 0.4):
                tx = int(ex + math.cos(self.angle + off + math.pi) * tip)
                ty = int(ey + math.sin(self.angle + off + math.pi) * tip)
                draw.line(ex, ey, tx, ty, LIGHT_BLUE)

    def hits_point(self, px, py, margin=7):
        l = self._cur_len()
        if l < 8:
            return False
        dx = math.cos(self.angle);  dy = math.sin(self.angle)
        t  = (px - self.x1)*dx + (py - self.y1)*dy
        if t < 0 or t > l:
            return False
        cx = self.x1 + t*dx;  cy = self.y1 + t*dy
        return math.sqrt((px-cx)**2 + (py-cy)**2) < margin

def spawn_ice_spikes():
    for _ in range(3 + random.randint(0, 3)):
        ice_spikes.append(IceSpike())

# =========================================================
# PLAYER
# =========================================================
player_x   = 20.0
player_y   = 190.0
player_dir = 1
PLAYER_SPD = 90

# =========================================================
# INIT
# =========================================================
def init():
    global player_hp, inv_timer, phase, totems_killed
    global ray_timer, ray_burst_state, ray_burst_timer
    global rad_timer, rad_wave_count, rad_wave_gap
    global ice_timer, wander_timer
    global boss_target_x, boss_target_y
    global player_x, player_y, player_dir
    global WEAPON_TYPE

    WEAPON_TYPE = game_state.WEAPON_TYPE

    player_hp  = PLAYER_MAX_HP
    inv_timer  = 0
    phase      = 1   # starts in phase 1 — ray star active from full health
    totems_killed = 0

    ray_timer       = 80
    ray_burst_state = 0
    ray_burst_timer = 0
    rad_timer       = 0
    rad_wave_count  = 0
    rad_wave_gap    = 0
    ice_timer       = 0
    wander_timer    = 0

    boss_target_x = 150.0
    boss_target_y = 70.0
    player_x      = 160.0
    player_y      = 190.0
    player_dir    = 1

    rays.clear()
    rad_waves.clear()
    ice_spikes.clear()

    gun.bullets.clear()
    gun.ammo         = gun.max_ammo
    gun.reload_timer = 0
    sword.timer      = 0
    trident.timer    = 0;  trident.vfx = 0
    pickaxe.timer    = 0
    pimpillo.active     = False
    pimpillo.zone_active = False
    pimpillo.cooldown    = 0

    # spawn 4 totems at corners
    totems.clear()
    for x, y in CORNER_POSITIONS:
        totems.append(Totem(x, y))

    _make_sprites()

# =========================================================
# UPDATE — returns "WIN", "LOSE", or None
# =========================================================
def update():
    global player_hp, inv_timer, phase, totems_killed
    global ray_timer, ray_burst_state, ray_burst_timer
    global rad_timer, rad_wave_count, rad_wave_gap
    global ice_timer, wander_timer
    global boss_target_x, boss_target_y
    global player_x, player_y, player_dir

    if inv_timer > 0: inv_timer -= 1

    # ---- phase check based on totems killed ----
    if totems_killed >= 3 and phase < 3:
        phase = 3
        boss_obj.currNdx(3)
    elif totems_killed >= 2 and phase < 2:
        phase = 2
        boss_obj.currNdx(2)

    # ---- player movement ----
    spd = PLAYER_SPD * dt()
    dx = 0.0;  dy = 0.0
    if kb.read_left()  == 0:
        dx = -spd
        if player_dir != -1:  player_dir = -1;  player_obj.flip(0)
    if kb.read_right() == 0:
        dx = spd
        if player_dir != 1:   player_dir = 1;   player_obj.flip(1)
    if kb.read_up()   == 0:   dy = -spd
    if kb.read_down() == 0:   dy =  spd
    if dx != 0 and dy != 0:   dx *= 0.707;  dy *= 0.707

    player_x = max(0, min(player_x + dx, SCREEN_W - 12))
    player_y = max(0, min(player_y + dy, SCREEN_H - 12))
    player_obj.pos_x = int(player_x)
    player_obj.pos_y = int(player_y)

    px = int(player_x);  py = int(player_y)

    # ---- weapon input ----
    if kb.B_down():
        if   WEAPON_TYPE == "GUN":      gun.shoot(px, py, player_dir)
        elif WEAPON_TYPE == "SWORD":    sword.attack()
        elif WEAPON_TYPE == "TRIDENT":  trident.attack()
        elif WEAPON_TYPE == "PICKAXE":  pickaxe.attack()
        elif WEAPON_TYPE == "PIMPILLO": pimpillo.attack(px, py, player_dir)

    gun.update();  sword.update();  trident.update();  pickaxe.update();  pimpillo.update()

    # ---- totem updates + hit detection ----
    wx = px + 5
    for t in totems:
        t.update()
        if not t.alive:
            continue

        killed = False
        for b in gun.bullets:
            if t.obj.colliderPt(int(b.x), int(b.y)):
                if t.try_hit(weapons.Gun.DAMAGE):  killed = True
                b.alive = False
                break
        if not killed and WEAPON_TYPE == "SWORD" and sword.is_busy():
            for hx, hy in sword.hit_points(wx, py, player_dir):
                if t.obj.colliderPt(hx, hy):
                    if t.try_hit(weapons.Sword.DAMAGE): killed = True
                    break
        if not killed and WEAPON_TYPE == "PICKAXE" and pickaxe.timer > 0:
            for hx, hy in pickaxe.hit_points(wx, py, player_dir):
                if t.obj.colliderPt(hx, hy):
                    if t.try_hit(weapons.Pickaxe.DAMAGE): killed = True
                    break
        if not killed and WEAPON_TYPE == "TRIDENT" and trident.timer > 0:
            for hx, hy in trident.hit_points(wx, py, player_dir):
                if t.obj.colliderPt(hx, hy):
                    if t.try_hit(weapons.Trident.DAMAGE): killed = True
                    break
        if not killed and WEAPON_TYPE == "PIMPILLO":
            pimpillo.hit_enemy(lambda hx, hy: t.obj.colliderPt(hx, hy))
            for hx, hy in pimpillo.zone_hit_points():
                if t.obj.colliderPt(hx, hy):
                    if t.try_hit(weapons.Pimpillo.DAMAGE): killed = True
                    break

        if killed:
            totems_killed += 1

    # ---- boss wander ----
    bx = int(boss_obj.pos_x);  by = int(boss_obj.pos_y)
    wander_timer += 1
    if wander_timer >= WANDER_CD:
        wander_timer  = 0
        boss_target_x = float(random.randint(50, SCREEN_W - 50))
        boss_target_y = float(random.randint(20, SCREEN_H // 2 - 20))

    wdx = boss_target_x - bx;  wdy = boss_target_y - by
    wd  = max(1, math.sqrt(wdx*wdx + wdy*wdy))
    if wd > 3:
        boss_obj.speed_x = (wdx/wd) * BOSS_SPD
        boss_obj.speed_y = (wdy/wd) * BOSS_SPD
    else:
        boss_obj.speed_x = 0;  boss_obj.speed_y = 0
    boss_obj.clamp_x(20, SCREEN_W - 40)
    boss_obj.clamp_y(10, SCREEN_H // 2 - 10)
    boss_obj.update()

    bx = int(boss_obj.pos_x);  by = int(boss_obj.pos_y)

    # ---- ATK1: ray star (always active — phase 1 from full health) ----
    ray_timer += 1
    if ray_burst_state == 0 and ray_timer >= RAY_BURST_CD:
        ray_timer = 0
        fire_ray_burst(bx, by, 0.0)
        ray_burst_state = 1
        ray_burst_timer = 0
    if ray_burst_state == 1:
        ray_burst_timer += 1
        if ray_burst_timer >= RAY_BURST_GAP:
            fire_ray_burst(bx, by, math.pi / RAY_COUNT)
            ray_burst_state = 0

    # ---- ATK2: radiation wave (phase 2 — 2 totems killed) ----
    if phase >= 2:
        rad_timer += 1
        if rad_wave_count == 0 and rad_timer >= RAD_WAVE_CD:
            rad_timer      = 0
            rad_wave_count = 1
            rad_wave_gap   = 0
            rad_waves.append(RadWave(bx, by))
        if rad_wave_count == 1:
            rad_wave_gap += 1
            if rad_wave_gap >= RAD_WAVE_SPACING:
                rad_wave_count = 0
                rad_waves.append(RadWave(bx, by))

    # ---- ATK3: ice spikes (phase 3 — 3 totems killed) ----
    if phase >= 3:
        ice_timer += 1
        if ice_timer >= ICE_SPIKE_CD:
            ice_timer = 0
            spawn_ice_spikes()

    # ---- update rays ----
    i = 0
    while i < len(rays):
        r = rays[i]
        r.update()
        if not r.alive:
            rays.pop(i)
        else:
            if r.hits_point(int(player_obj.mid_x), int(player_obj.mid_y)):
                try_hit_player(1)
            i += 1

    # ---- update rad waves ----
    i = 0
    while i < len(rad_waves):
        w = rad_waves[i]
        w.update()
        if not w.alive:
            rad_waves.pop(i)
        else:
            if w.hits_point(int(player_obj.mid_x), int(player_obj.mid_y)):
                try_hit_player(1)
            i += 1

    # ---- update ice spikes ----
    i = 0
    while i < len(ice_spikes):
        s = ice_spikes[i]
        s.update()
        if not s.alive:
            ice_spikes.pop(i)
        else:
            if s.hits_point(int(player_obj.mid_x), int(player_obj.mid_y)):
                try_hit_player(1)
            i += 1

    # all totems dead = WIN
    if totems_killed >= 4:  return "WIN"
    if player_hp    <= 0:   return "LOSE"
    return None

# =========================================================
# DRAW
# =========================================================
def draw_scene():
    draw.clear(0)

    for s in ice_spikes:   s.draw()
    for w in rad_waves:    w.draw()
    for r in rays:         r.draw()
    for t in totems:       t.draw()

    boss_obj.draw()
    # light-blue border so boss is visible even if sprite is transparent
    draw.rect(int(boss_obj.pos_x)-2, int(boss_obj.pos_y)-2,
              boss_obj.width+4, boss_obj.height+4, LIGHT_BLUE)
    player_obj.draw()

    px = int(player_x);  py = int(player_y)
    bx = int(boss_obj.pos_x);  by = int(boss_obj.pos_y)

    if wep_sprite:
        wep_sprite.pos_x = px+5;  wep_sprite.pos_y = py
        wep_sprite.draw()
    gun.draw(draw)
    sword.draw(draw, px+5, py, player_dir)
    trident.draw(draw, px+5, py, player_dir)
    pickaxe.draw(draw, px+5, py, player_dir)
    pimpillo.draw(draw)

    # totem counter top-centre
    alive = sum(1 for t in totems if t.alive)
    draw.text("TOTEMS:" + str(alive) + "/4", 118, 4, LIGHT_BLUE)

    # phase label near boss — extended to cover phases 1-3
    phase_labels = ["", "PHASE 1", "PHASE 2", "PHASE 3"]
    draw.text(phase_labels[phase], bx - 18, by - 22, LIGHT_BLUE)

    # player HP
    draw.filled_rect(4, 4, 60, 5, 7)
    draw.filled_rect(4, 4, int(60*(player_hp/PLAYER_MAX_HP)), 5, 3)