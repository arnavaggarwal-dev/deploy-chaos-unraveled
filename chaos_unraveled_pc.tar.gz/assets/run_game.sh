#!/usr/bin/env bash
echo "Chaos Unraveled - PC Port"
echo ""
python3 -c "import pygame" 2>/dev/null || pip3 install pygame
echo ""
echo "Controls:"
echo "  Arrow Keys = Move"
echo "  Z          = A button (confirm / shoot)"
echo "  X          = B button"
echo "  Q          = Left Shoulder (exit sub-map)"
echo "  ESC        = Quit"
echo ""
cd "$(dirname "$0")"
python3 main.py
