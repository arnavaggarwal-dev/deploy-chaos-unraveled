# Chaos Unraveled — PC Port
# Original retroPy game, ported to run with pygame via retroPy.py shim.

from retroPy import *
import game_state
import map_level
import boss_fight
import boss_fight2
import boss_fight3
import boss_fight4
import pantheon
import map2
import inventory_overlay

# disp.init() was hardware-only — skipped on PC

# =========================================================
# SCENE MANAGER
# =========================================================
game_state.scene  = "MAP"
game_state.result = None
map_level.init_select()

RESULT_HOLD  = 180
result_timer = 0
SCREEN_H     = 240

def enter_result(outcome, boss_id=None):
    global result_timer
    game_state.result = outcome
    game_state.scene  = "RESULT"
    result_timer      = RESULT_HOLD
    if outcome == "WIN":
        if boss_id == "BOSS" and not game_state.boss1_key_given:
            game_state.keys_collected  = min(9, game_state.keys_collected + 1)
            game_state.boss1_key_given = True
        elif boss_id == "BOSS2" and not game_state.boss2_key_given:
            game_state.keys_collected  = min(9, game_state.keys_collected + 1)
            game_state.boss2_key_given = True
        elif boss_id == "BOSS3" and not game_state.boss3_key_given:
            game_state.keys_collected  = min(9, game_state.keys_collected + 1)
            game_state.boss3_key_given = True
        elif boss_id == "BOSS4" and not getattr(game_state, 'boss4_key_given', False):
            game_state.keys_collected  = min(9, game_state.keys_collected + 1)
            game_state.boss4_key_given = True

# =========================================================
# UPDATE
# =========================================================
def Update():
    global result_timer

    if kb.read_up() == 0 and kb.read_B() == 0 and kb.A_down():
        if inventory_overlay.is_open:
            inventory_overlay.close_overlay()
        else:
            inventory_overlay.open_overlay()
    if inventory_overlay.is_open:
        inventory_overlay.update()
        return

    scene = game_state.scene

    if scene == "MAP":
        transition = map_level.update()
        if transition == "BOSS":
            game_state.scene = "BOSS"
            boss_fight.init()
        if transition == "BOSS3":
            game_state.scene = "BOSS3"
            boss_fight3.init()
        if transition == "PANTHEON":
            game_state.scene = "PANTHEON"
            pantheon.init()
        if transition == "MAP2":
            game_state.scene = "MAP2"
            map2.init()
        if transition == "CUTSCENE":
            game_state.scene = "CUTSCENE"
        if not map_level.in_select:
            if kb.read_up() == 1 and kb.B_down():
                game_state.scene = "BOSS2"
                boss_fight2.init()

    elif scene == "BOSS":
        outcome = boss_fight.update()
        if outcome in ("WIN", "LOSE"):
            enter_result(outcome, "BOSS")

    elif scene == "BOSS2":
        outcome = boss_fight2.update()
        if outcome in ("WIN", "LOSE"):
            enter_result(outcome, "BOSS2")

    elif scene == "BOSS3":
        outcome = boss_fight3.update()
        if outcome in ("WIN", "LOSE"):
            enter_result(outcome, "BOSS3")

    elif scene == "BOSS4":
        outcome = boss_fight4.update()
        if outcome == "WIN":
            game_state.scene = "TRUE_END"
        elif outcome == "LOSE":
            enter_result("LOSE", "BOSS4")

    elif scene == "PANTHEON":
        outcome = pantheon.update()
        if outcome == "LOSE":
            game_state.scene = "MAP"
            map_level.init()
        if pantheon.phase in ("CLEARED", "FAILED"):
            if kb.A_down():
                game_state.scene = "MAP"
                map_level.init()

    elif scene == "MAP2":
        transition2 = map2.update()
        if transition2 == "PANTHEON":
            game_state.scene = "PANTHEON"
            pantheon.init()
        if kb.Tleft_down():
            game_state.scene = "MAP"
            map_level.init()

    elif scene == "CUTSCENE":
        done = map_level.update_cutscene()
        if done:
            game_state.scene = "BOSS4"
            boss_fight4.init()

    elif scene == "RESULT":
        result_timer -= 1
        if result_timer <= 0:
            game_state.scene = "MAP"
            map_level.init()

# =========================================================
# DRAW
# =========================================================
def Draw():
    scene = game_state.scene

    if inventory_overlay.is_open:
        inventory_overlay.draw_scene()
        return

    if scene == "MAP":
        map_level.draw_scene()
    elif scene == "BOSS":
        boss_fight.draw_scene()
    elif scene == "BOSS2":
        boss_fight2.draw_scene()
    elif scene == "BOSS3":
        boss_fight3.draw_scene()
    elif scene == "BOSS4":
        boss_fight4.draw_scene()
    elif scene == "PANTHEON":
        pantheon.draw_scene()
    elif scene == "MAP2":
        map2.draw_scene()
    elif scene == "TRUE_END":
        draw.clear(0)
        draw.filled_rect(10, 10, 300, 220, 1)
        draw.rect(10, 10, 300, 220, 15)
        draw.text("THE WITCH IS SLAIN.",     80,  50, 15)
        draw.text("The vault is silent.",    80,  70,  7)
        draw.text("All 9 keys collected.",   80,  88, 14)
        draw.text("The secret is yours.",    80, 106,  9)
        draw.text("YOU WIN.",               120, 135, 10)
    elif scene == "CUTSCENE":
        map_level.draw_cutscene()
    elif scene == "RESULT":
        draw.clear(0)
        if game_state.result == "WIN":
            draw.text("VICTORY!",              120, 80,  10)
            draw.text("The boss has fallen.",   80, 96,  15)
            draw.text("KEY OBTAINED!",         100, 112, 14)
            draw.text("Keys: "+str(game_state.keys_collected)+"/9", 120, 124, 14)
            draw.text("Returning to safety...", 72, 136,  7)
        else:
            draw.text("YOU DIED.",               116, 90,  2)
            draw.text("The boss was too strong.", 68, 106, 15)
            draw.text("Returning to safety...",   72, 118,  7)

# =========================================================
# RUN
# =========================================================
import asyncio

async def main():
    gl = gameloop(Update, Draw)
    await gl.run_async()

asyncio.run(main())
